package com.uepca.gestioninv.controller;

/**
 *
 * @author D_Ale
 */
public class ControllerC {
    
}
