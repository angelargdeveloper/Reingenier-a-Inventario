package com.uepca.gestioninv.controller;


import com.uepca.gestioninv.db.ConexionMySQL;
import com.uepca.gestioninv.model.Venta;
import com.uepca.gestioninv.model.DetalleVenta;
import com.uepca.gestioninv.model.Producto;
import com.uepca.gestioninv.model.Empleado;
import com.uepca.gestioninv.model.Proveedor;
import java.util.List;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.sql.SQLException;



public class ControllerVenta {
    
    public List<Venta> getAll(String filtro) throws Exception {
        String sql = "SELECT * FROM v_venta";
        ConexionMySQL connMySQL = new ConexionMySQL();
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<Venta> compra = new ArrayList<>();
        
        try {
            conn = connMySQL.open();
            conn.setAutoCommit(false); 
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            
            while (rs.next())
                compra.add(fill(rs));
            
        } 
        catch (SQLException ex) 
        {
            ex.printStackTrace();
            throw new Exception("Error al obtener las ventas", ex);
        } 
        finally 
        {
            if (rs != null) 
                rs.close();
            if (pstmt != null) 
                pstmt.close();
            if (conn != null) {
                conn.setAutoCommit(true); // Restaurar 
                conn.close();
            }
        }
        
        return compra;
    }
    
    private Venta fill(ResultSet rs) throws Exception {
        Venta v = new Venta();
        Empleado e = new Empleado();
        Producto p = new Producto();

        v.setId(rs.getInt("idVenta"));
        e.setId(rs.getInt("idEmpleado"));
        e.setNombre(rs.getString("nombreEmpleado"));
        e.setEstatus(rs.getInt("estatus"));
        p.setId(rs.getInt("idProducto"));
        p.setNombre(rs.getString("nombreProducto"));
        p.setPrecio(rs.getFloat("precioUnitario"));
        p.setCantidad(rs.getInt("PCant"));
        p.setEstatus(rs.getInt("PEst"));
        v.setCantidad(rs.getInt("cantidad"));
        v.setPrecioVenta(rs.getFloat("precioVenta"));
        v.setDescuento(rs.getFloat("descuento"));
        v.setFecha(rs.getString("fechaVenta")); 
        v.setEstatus(rs.getInt("VEst"));

        v.setEmpleado(e);
        v.setProducto(p);

        return v;
    }
    
    public int insert(Venta v) throws Exception {
    String sql ="INSERT INTO venta(idEmpleado, fechaVenta) VALUES (?, ?)";
    String sqlDetalle = "INSERT INTO detalle_venta(idVenta, idProducto, cantidad, precioVenta, descuento) VALUES (?, ?, ?, ?, ?)";
    ConexionMySQL connMySQL = new ConexionMySQL();
    Connection conn = null;
    PreparedStatement pstmtVenta = null;
    PreparedStatement pstmtDetalle = null;
    ResultSet rsVenta = null;
    ResultSet rsDetalle = null;

    try {
        conn = connMySQL.open();
        conn.setAutoCommit(false); // Desactivar autocommit
        
        // Insertar en la tabla venta
        pstmtVenta = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
        pstmtVenta.setInt(1, v.getEmpleado().getId());
        pstmtVenta.setString(2, v.getFecha());
        pstmtVenta.executeUpdate();
        
        // Recuperar el ID de la venta insertada
        rsVenta = pstmtVenta.getGeneratedKeys();
        int ventaId = -1; //indicar que no se ha encontrado ningún ID de compra generado
        if (rsVenta.next())
            ventaId = rsVenta.getInt(1);
        
        // Insertar en la tabla detalle_compra
        for (DetalleVenta dv : v.getDetalleVentas()) {
            pstmtDetalle = conn.prepareStatement(sqlDetalle, PreparedStatement.RETURN_GENERATED_KEYS);
            pstmtDetalle.setInt(1, ventaId);
            pstmtDetalle.setInt(2, dv.getProducto().getId());
            pstmtDetalle.setInt(3, dv.getCantidad());
            pstmtDetalle.setFloat(4, dv.getPrecioVenta());            
            pstmtDetalle.setFloat(5, dv.getDescuento());
            pstmtDetalle.executeUpdate();
        }
        
        // Confirmar la transacción
        conn.commit();
        
        return ventaId; // Retornar el ID de la compra insertada
        } catch (SQLException ex) {
        if (conn != null) 
            conn.rollback(); // Deshacer la transacción en caso de error
        ex.printStackTrace();
        throw new Exception("Error al insertar la venta: " + ex.getMessage());
        } finally {
        // Cerrar recursos
        if (rsVenta != null) 
            rsVenta.close();
        if (rsDetalle != null) 
            rsDetalle.close();
        if (pstmtVenta != null) 
            pstmtVenta.close();
        if (pstmtDetalle != null) 
            pstmtDetalle.close();
        if (conn != null) {
            conn.setAutoCommit(true); // Restaurar autocommit
            conn.close();
            }
        }
    }

    
    
    public void update(Venta v) throws Exception {
        String sql = "UPDATE venta SET idEmpleado = ?, fechaVenta = ? WHERE idVenta = ?";
        String sqlDetalle = "UPDATE detalle_venta SET idProducto=?, cantidad=?, precioventa=?, descuento=? WHERE idVenta = ?";
        ConexionMySQL connMySQL = new ConexionMySQL();
        Connection conn = null;
        PreparedStatement pstmtVenta = null;
        PreparedStatement pstmtDetalle = null;
        ResultSet rsVenta = null;
        ResultSet rsDetalle = null;

        try {
        conn = connMySQL.open();
        conn.setAutoCommit(false); // Desactivar autocommit
        
        // Insertar en la tabla venta
        pstmtVenta = conn.prepareStatement(sql);
        pstmtVenta.setInt(1, v.getEmpleado().getId());
        pstmtVenta.setString(2, v.getFecha());
        pstmtVenta.setInt(3, v.getId());
        pstmtVenta.executeUpdate();
        
        // Recuperar el ID de la venta insertada
        /*rsVenta = pstmtVenta.get;
        int compraId = -1; //indicar que no se ha encontrado ningún ID de venta generado
        if (rsVenta.next())
            ventaId = rsVenta.getInt(1);*/
        int ventaId = v.getId();
        // Insertar en la tabla detalle_venta
        for (DetalleVenta dv : v.getDetalleVentas()) {
            pstmtDetalle = conn.prepareStatement(sqlDetalle, PreparedStatement.RETURN_GENERATED_KEYS);
            pstmtDetalle.setInt(1, dv.getProducto().getId());   
            pstmtDetalle.setInt(2, dv.getCantidad());
            pstmtDetalle.setFloat(3, dv.getPrecioVenta());            
            pstmtDetalle.setFloat(4, dv.getDescuento());
            pstmtDetalle.setInt(5, ventaId);
            pstmtDetalle.executeUpdate();
        }
        
        // Confirmar la transacción
        conn.commit(); // Confirmar la transacción
        System.out.println(pstmtVenta.toString());//se imprime el pstmt de la venta en consola
        System.out.println(pstmtDetalle.toString());//se imprime el pstmt del detalle de venta en consola
        } 
        catch (SQLException ex) {
            if (conn != null) 
                conn.rollback(); // Deshacer la transacción en caso de error
            
            ex.printStackTrace();
            throw new Exception("Error al actualizar la venta", ex);
        } 
        finally 
        {
            if (pstmtVenta != null) 
                pstmtVenta.close();
            
            if (pstmtDetalle != null) 
                pstmtDetalle.close();
            
            if (conn != null) {
                conn.setAutoCommit(true); // Restaurar autocommit
                conn.close();
            }
        }
    }
    
    public void softDelete(Venta v) throws Exception {
        String sql = "UPDATE venta SET estatus = ? WHERE idVenta = ?";
        ConexionMySQL connMySQL = new ConexionMySQL();
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = connMySQL.open();
            conn.setAutoCommit(false); // Desactivar autocommit
            pstmt = conn.prepareStatement(sql);

            // Establecemos los valores de los parámetros para la actualización
            pstmt.setInt(1, 0);
            pstmt.setInt(2, v.getId());
            
            // Ejecutamos la consulta
            pstmt.executeUpdate();
            
            conn.commit(); // Confirmar la transacción
        } 
        catch (SQLException ex) {
            if (conn != null) 
                conn.rollback(); // Deshacer la transacción en caso de error
            
            ex.printStackTrace();
            throw new Exception("Error al eliminar la venta", ex);
        } 
        finally 
        {
            if (pstmt != null) 
                pstmt.close();
            if (conn != null) {
                conn.setAutoCommit(true); // Restaurar autocommit
                conn.close();
            }
        }
    }
}