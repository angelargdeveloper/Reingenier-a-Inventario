package com.uepca.gestioninv.controller;

import com.uepca.gestioninv.db.ConexionMySQL;
import com.uepca.gestioninv.model.Categoria;
import java.util.List;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.sql.SQLException;

/**
 *
 * @author D_Ale
 */
public class ControllerCategoria {
    public int insert(Categoria c) throws Exception{
        String sql ="INSERT INTO categoria(descripcion) VALUES(?)";
        ConexionMySQL connMuSQL = new ConexionMySQL();
        Connection conn = connMuSQL.open();
        PreparedStatement pstmt = conn.prepareStatement(sql,PreparedStatement.RETURN_GENERATED_KEYS);
        ResultSet rs = null;
        
        //Llenamos los valores de la consulta:
        pstmt.setString(1, c.getDescripcion());
        
      
        //Ejecutamos la consulta:
        pstmt.executeUpdate();
        
        //Recuperamos el ID que se insertó:
        rs = pstmt.getGeneratedKeys();
        if(rs.next())
            c.setId(rs.getInt(1));
        
        //Cerramos conexion:
        rs.close();
        pstmt.close();
        conn.close();
        
        return c.getId();
    }
    
    public void update(Categoria c) throws Exception{
        String sql = "UPDATE categoria SET descripcion=? WHERE idCategoria=?";
        ConexionMySQL connMySQL = new ConexionMySQL();
        Connection conn = connMySQL.open();
        PreparedStatement pstmt = conn.prepareStatement(sql);
    
        // Llenamos los valores de la consulta:
        pstmt.setString(1, c.getDescripcion());
        pstmt.setInt(2, c.getId()); // El ID de la categoria que se actualizará
    
        // Ejecutamos la consulta:
        pstmt.executeUpdate();
    
        // Cerramos conexión:
        pstmt.close();
        conn.close();

    }
    
    public void delete(Categoria c) throws Exception{
        String sql = "UPDATE categoria SET estatus=? WHERE idCategoria=?";
        ConexionMySQL connMySQL = new ConexionMySQL();
        Connection conn = connMySQL.open();
        PreparedStatement pstmt = conn.prepareStatement(sql);
    
        // Llenamos los valores de la consulta:
        pstmt.setInt(1, 0);
        pstmt.setInt(2, c.getId());// El ID de la categoria que se actualizará
        
        // Ejecutamos la consulta:
        pstmt.executeUpdate();
    
        // Cerramos conexión:
        pstmt.close();
        conn.close();
    }
    
    public List<Categoria> getAll(String filtro) throws Exception{
        String sql = "SELECT * FROM categoria";
        List<Categoria> categorias = new ArrayList<>();
        ConexionMySQL connMySQL = new ConexionMySQL();
        Connection conn = connMySQL.open();
        PreparedStatement pstmt = conn.prepareStatement(sql);
        ResultSet rs = pstmt.executeQuery();
        
        while(rs.next())
            categorias.add(fill(rs));
        
        rs.close();
        pstmt.close();
        conn.close();
        
        return categorias;
    }
    
    private Categoria fill(ResultSet rs) throws Exception{
        Categoria c = new Categoria();
        c.setId(rs.getInt("idCategoria"));
        c.setDescripcion(rs.getString("descripcion"));
        c.setEstatus(rs.getInt("estatus"));
        
        return c;
    }
}
