package com.uepca.gestioninv.controller;

import com.uepca.gestioninv.db.ConexionMySQL;
import com.uepca.gestioninv.model.Area;
import java.util.List;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.sql.SQLException;
/**
 *
 * @author D_Ale
 */
public class ControllerArea {
    public int insert(Area a) throws Exception{
        String sql ="INSERT INTO gestion_inv.area(descripcion)value(?)";
        ConexionMySQL connMySQL = new ConexionMySQL();
        Connection conn = connMySQL.open();
        PreparedStatement pstmt = conn.prepareStatement(sql,PreparedStatement.RETURN_GENERATED_KEYS);
        ResultSet rs = null;
        
        //Llenamos los valores de la consulta:
        pstmt.setString(1, a.getDescripcion());
        
      
        //Ejecutamos la consulta:
        pstmt.executeUpdate();
        
        //Recuperamos el ID que se insertó:
        rs = pstmt.getGeneratedKeys();
        if(rs.next())
            a.setId(rs.getInt(1));
        
        //Cerramos conexion:
        rs.close();
        pstmt.close();
        conn.close();
        
        return a.getId();
    }
    
    public void update(Area a) throws Exception{
        String sql = "UPDATE area SET descripcion=? WHERE idArea=?";
        ConexionMySQL connMySQL = new ConexionMySQL();
        Connection conn = connMySQL.open();
        PreparedStatement pstmt = conn.prepareStatement(sql);
    
        // Llenamos los valores de la consulta:
        pstmt.setString(1, a.getDescripcion());
        pstmt.setInt(2, a.getId()); // El ID del producto que se actualizará
    
        // Ejecutamos la consulta:
        pstmt.executeUpdate();
    
        // Cerramos conexión:
        pstmt.close();
        conn.close();

    }
    
    public void delete(Area a) throws Exception{
        String sql = "UPDATE area SET estatus=? WHERE idArea=?";
        ConexionMySQL connMySQL = new ConexionMySQL();
        Connection conn = connMySQL.open();
        PreparedStatement pstmt = conn.prepareStatement(sql);
    
        // Llenamos los valores de la consulta:
        pstmt.setInt(1, 0);
        pstmt.setInt(2, a.getId());// El ID del grupo que se actualizará
        
        // Ejecutamos la consulta:
        pstmt.executeUpdate();
    
        // Cerramos conexión:
        pstmt.close();
        conn.close();
    }
    
    public List<Area> getAll(String filtro) throws Exception{
        String sql = "SELECT * FROM area WHERE estatus=1";
        List<Area> areas = new ArrayList<>();
        ConexionMySQL connMySQL = new ConexionMySQL();
        Connection conn = connMySQL.open();
        PreparedStatement pstmt = conn.prepareStatement(sql);
        ResultSet rs = pstmt.executeQuery();
        
        while(rs.next())
            areas.add(fill(rs));
        
        rs.close();
        pstmt.close();
        conn.close();
        
        return areas;
    }
    
    private Area fill(ResultSet rs) throws Exception{
        Area a = new Area();
        a.setId(rs.getInt("idArea"));
        a.setDescripcion(rs.getString("descripcion"));
        a.setEstatus(rs.getInt("estatus"));
        
        return a;
    }
}
