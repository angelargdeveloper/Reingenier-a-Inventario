package com.uepca.gestioninv.controller;

import com.uepca.gestioninv.db.ConexionMySQL;
import com.uepca.gestioninv.model.Usuario;
import com.uepca.gestioninv.model.Empleado;
import com.uepca.gestioninv.model.Area;
import java.util.List;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.sql.SQLException;
/**
 *
 * @author D_Ale
 */
public class ControllerUsuario {
    public int insert(Usuario u) throws Exception{
        String sql ="INSERT INTO usuario(usuario,pass,idEmpleado) VALUES(?,?,?)";
        ConexionMySQL connMuSQL = new ConexionMySQL();
        Connection conn = connMuSQL.open();
        PreparedStatement pstmt = conn.prepareStatement(sql,PreparedStatement.RETURN_GENERATED_KEYS);
        ResultSet rs = null;
        
        //Llenamos los valores de la consulta:
        pstmt.setString(1, u.getUsuario());
        pstmt.setString(2, u.getPass());
        pstmt.setInt(3, u.getEmpleado().getId());
        
      
        //Ejecutamos la consulta:
        pstmt.executeUpdate();
        
        //Recuperamos el ID que se insertó:
        rs = pstmt.getGeneratedKeys();
        if(rs.next())
            u.setId(rs.getInt(1));
        
        //Cerramos conexion:
        rs.close();
        pstmt.close();
        conn.close();
        
        return u.getId();
    }
    
    public void update(Usuario u) throws Exception{
        String sql = "UPDATE usuario SET usuario=?, pass=? WHERE idUsuario=?";
        ConexionMySQL connMySQL = new ConexionMySQL();
        Connection conn = connMySQL.open();
        PreparedStatement pstmt = conn.prepareStatement(sql);
    
        // Llenamos los valores de la consulta:
        pstmt.setString(1, u.getUsuario());
        pstmt.setString(2, u.getPass());
        pstmt.setInt(3, u.getId()); // El ID del usuario que se actualizará
    
        // Ejecutamos la consulta:
        pstmt.executeUpdate();
    
        // Cerramos conexión:
        pstmt.close();
        conn.close();

    }
    
    public void delete(Usuario u) throws Exception{
        String sql = "UPDATE usuario SET estatus=? WHERE idUsuario=?";
        ConexionMySQL connMySQL = new ConexionMySQL();
        Connection conn = connMySQL.open();
        PreparedStatement pstmt = conn.prepareStatement(sql);
    
        // Llenamos los valores de la consulta:
        pstmt.setInt(1, 0);
        pstmt.setInt(2, u.getId());// El ID del usuario que se actualizará
        
        // Ejecutamos la consulta:
        pstmt.executeUpdate();
    
        // Cerramos conexión:
        pstmt.close();
        conn.close();
    }
    
    public List<Usuario> getAll(String filtro) throws Exception{
        String sql = "SELECT * FROM v_usuario";
        List<Usuario> usuarios = new ArrayList<>();
        ConexionMySQL connMySQL = new ConexionMySQL();
        Connection conn = connMySQL.open();
        PreparedStatement pstmt = conn.prepareStatement(sql);
        ResultSet rs = pstmt.executeQuery();
        
        while(rs.next())
            usuarios.add(fill(rs));
        
        rs.close();
        pstmt.close();
        conn.close();
        
        return usuarios;
    }
    
    private Usuario fill(ResultSet rs) throws Exception{
        Usuario u = new Usuario();
        Empleado e = new Empleado();
        Area a = new Area();
        
        u.setId(rs.getInt("idUsuario"));
        u.setUsuario(rs.getString("Usuario"));
        u.setPass(rs.getString("Pass"));
        
        e.setId(rs.getInt("idEmpleado"));
        e.setNombre(rs.getString("ENombre"));
        e.setFechaAlta(rs.getString("EAlta"));
        e.setFechaNac(rs.getString("ENac"));
        e.setDireccion(rs.getString("EDir"));
        e.setPoblacion(rs.getString("EPob"));
        e.setCodPostal(rs.getString("ECod"));
        e.setTelefono(rs.getString("ETel"));
        e.setEstatus(rs.getInt("EEst"));
        
        a.setId(rs.getInt("idArea"));
        a.setDescripcion(rs.getString("ADes"));
        a.setEstatus(rs.getInt("AEst"));
        
        u.setEstatus(rs.getInt("UEst"));
        
        e.setArea(a);
        u.setEmpleado(e);
        
        
        return u;
    }
}
