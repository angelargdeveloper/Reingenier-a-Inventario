package com.uepca.gestioninv.rest;

import com.google.gson.Gson;
import com.uepca.gestioninv.controller.ControllerVenta;
import com.uepca.gestioninv.model.Venta;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

/**
 *
 * @author D_Ale
 */
@Path("venta")
public class RESTVenta {
    @Path("getAll")
    @Produces(MediaType.APPLICATION_JSON)
    @GET
    public Response getAll(@QueryParam("filtro") @DefaultValue("") String filtro)
    {
        String out=null;
        List<Venta> ventas = null;
        ControllerVenta cv = new ControllerVenta();
        Gson gson = new Gson();
        try
        {
            ventas = cv.getAll(filtro);
            out = gson.toJson(ventas);
        }
        catch(Exception e)
        {
            out = """
                  {
                    "exception" : "%s"
                  }
                  """;
            out = String.format(out, e.toString().replaceAll("\"", ""));
        }
        
        return Response.ok(out).build();
    }
    
    @POST
    @Path("save")
    @Produces(MediaType.APPLICATION_JSON)
    public Response save(@FormParam("venta") String datosVenta)
    {
        String out = null;
        ControllerVenta cv = new ControllerVenta();
        Gson gson = new Gson();
        Venta v = null;
        try
        {
            v = gson.fromJson(datosVenta, Venta.class);
            if(v == null)
                out = "{\"error\":\"No se proporcionaron datos de la venta.\"}";
            else if(v.getId() == 0)
                cv.insert(v);
            else
                cv.update(v);
            out = new Gson().toJson(v);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            out = """
                  {
                    "exception":"%s"
                  }
                  """;
            out = String.format(out, e.toString().replaceAll("\"", ""));
        }
        return Response.ok(out).build();
    }
    
    
    @POST
    @Path("softdelete")
    @Produces(MediaType.APPLICATION_JSON)
    public Response softDelete(@FormParam("venta") String datosVenta)
    {
        String out = null;
        ControllerVenta cv = new ControllerVenta();
        Gson gson = new Gson();
        Venta v = null;
        try
        {
            v = gson.fromJson(datosVenta, Venta.class);
            if(v == null)
                out = "{\"error\":\"No se proporcionaron datos de la venta.\"}";
            else
                cv.softDelete(v);
            out = new Gson().toJson(v);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            out = """
                  {
                    "exception":"%s"
                  }
                  """;
            out = String.format(out, e.toString().replaceAll("\"", ""));
        }
        return Response.ok(out).build();
    }

}
