package com.uepca.gestioninv.rest;

import com.google.gson.Gson;
import com.uepca.gestioninv.controller.ControllerArea;
import com.uepca.gestioninv.model.Area;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

/**
 *
 * @author D_Ale
 */
@Path("area")
public class RESTArea {
    @GET
    @Path("getAll")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAll(@QueryParam("filtro") @DefaultValue("") String filtro){
        String out = null;
        ControllerArea ca = new ControllerArea();
        List<Area> areas = null;
        Gson gson = new Gson();
        try {
           areas = ca.getAll(filtro);
           out = gson.toJson(areas);
        } catch (Exception e) {
            e.printStackTrace();
            out = """
                  {
                    "exception":"%s"
                  }
                  """;
            
            out = String.format(out, e.toString().replaceAll("\"", ""));
        }
        return Response.ok(out).build();
    }
    
    @POST
    @Path("save")
    @Produces(MediaType.APPLICATION_JSON)
    public Response save(@FormParam("area") String datosArea){
        String out = null;
        ControllerArea ca = new ControllerArea();
        Gson gson = new Gson();
        Area a = null;
        try {
            a = gson.fromJson(datosArea, Area.class);
            if(a == null)
                out = "{\"error\";\"No se proporcionaron datos del área.\"}";
            else if(a.getId() == 0)
                ca.insert(a);
            else
                ca.update(a);
            out = new Gson().toJson(a);
        } catch (Exception ex) {
            ex.printStackTrace();
            out ="""
                 {
                    "exception":"%s"
                 }
                 """;
            out = String.format(out, ex.toString().replaceAll("\"", ""));
        }
        return Response.ok(out).build();
    }
}
