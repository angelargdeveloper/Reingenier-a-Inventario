package com.uepca.gestioninv.rest;

import com.uepca.gestioninv.controller.ControllerUsuario;
import com.uepca.gestioninv.model.Usuario;
import com.google.gson.Gson;
import com.uepca.gestioninv.model.Area;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
/**
 *
 * @author D_Ale
 */
@Path("usuario")
public class RESTUsuario {
    @GET
    @Path("getAll")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAll(@QueryParam("filtro") @DefaultValue("") String filtro){
        String out = null;
        ControllerUsuario cu = new ControllerUsuario();
        List<Usuario> usuarios = null;
        Gson gson = new Gson();
        try {
           usuarios = cu.getAll(filtro);
           out = gson.toJson(usuarios);
        } catch (Exception e) {
            e.printStackTrace();
            out = """
                  {
                    "exception":"%s"
                  }
                  """;
            
            out = String.format(out, e.toString().replaceAll("\"", ""));
        }
        return Response.ok(out).build();
    }
    
    @POST
    @Path("save")
    @Produces(MediaType.APPLICATION_JSON)
    public Response save(@FormParam("usuario") String datosUsuario){
        String out = null;
        ControllerUsuario cu = new ControllerUsuario();
        Gson gson = new Gson();
        Usuario u = null;
        try {
            u = gson.fromJson(datosUsuario, Usuario.class);
            if(u == null)
                out = "{\"error\";\"No se proporcionaron datos del usuario.\"}";
            else if(u.getId() == 0)
                cu.insert(u);
            else
                cu.update(u);
            out = new Gson().toJson(u);
        } catch (Exception ex) {
            ex.printStackTrace();
            out ="""
                 {
                    "exception":"%s"
                 }
                 """;
            out = String.format(out, ex.toString().replaceAll("\"", ""));
        }
        return Response.ok(out).build();
    }
    
    @POST
    @Path("borrar")
    @Produces(MediaType.APPLICATION_JSON)
    public Response borrar(@FormParam("usuario") String id){
        String out = null;
        ControllerUsuario cu = new ControllerUsuario();
        Gson gson = new Gson();
        Usuario u = null;
        try {
            u = gson.fromJson(id, Usuario.class);
            if(u == null)
                out = "{\"error\";\"No se proporcionaron datos del usuario.\"}";
            else if(u.getId() != 0)
                cu.delete(u);
            
            out = new Gson().toJson(u);
        } catch (Exception e) {
            e.printStackTrace();
            out ="""
                 {
                    "exception":"%s"
                 }
                 """;
            out = String.format(out, e.toString().replaceAll("\"", ""));
        }
        return Response.ok(out).build();
    }
}
