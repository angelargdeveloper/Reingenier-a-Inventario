package com.uepca.gestioninv.controller;

import com.uepca.gestioninv.db.ConexionMySQL;
import com.uepca.gestioninv.model.Categoria;
import com.uepca.gestioninv.model.Producto;
import java.util.List;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;

/**
 *
 * @author D_Ale
 */
public class ControllerProducto {
    public int insert(Producto p) throws Exception{
        String sql ="INSERT INTO producto(nombre,idCategoria,precio,cantidad) VALUES(?,?,?,?)";
        ConexionMySQL connMuSQL = new ConexionMySQL();
        Connection conn = connMuSQL.open();
        PreparedStatement pstmt = conn.prepareStatement(sql,PreparedStatement.RETURN_GENERATED_KEYS);
        ResultSet rs = null;
        
        //Llenamos los valores de la consulta:
        pstmt.setString(1, p.getNombre());
        pstmt.setInt(2, p.getCategoria().getId());
        pstmt.setDouble(3, p.getPrecio());
        pstmt.setDouble(4, p.getCantidad());
        
        //Ejecutamos la consulta:
        pstmt.executeUpdate();
        
        //Recuperamos el ID que se insertó:
        rs = pstmt.getGeneratedKeys();
        if(rs.next())
            p.setId(rs.getInt(1));
        
        //Cerramos conexion:
        rs.close();
        pstmt.close();
        conn.close();
        
        return p.getId();
    }
    
    public void update(Producto p)throws Exception{
        String sql = "UPDATE producto SET nombre=?, idCategoria=?, precio=?, cantidad=? WHERE idProducto=?";
        ConexionMySQL connMySQL = new ConexionMySQL();
        Connection conn = connMySQL.open();
        PreparedStatement pstmt = conn.prepareStatement(sql);
    
        // Llenamos los valores de la consulta:
        pstmt.setString(1, p.getNombre());
        pstmt.setInt(2, p.getCategoria().getId());
        pstmt.setDouble(3, p.getPrecio());
        pstmt.setDouble(4, p.getCantidad());
        pstmt.setInt(5, p.getId()); // El ID del producto que se actualizará
    
        // Ejecutamos la consulta:
        pstmt.executeUpdate();
    
        // Cerramos conexión:
        pstmt.close();
        conn.close();
    }
    
    public void delete(int id) throws Exception{
        String sql = "UPDATE producto SET estatus = 0 WHERE idProducto=?";
        ConexionMySQL connMySQL = new ConexionMySQL();
        Connection conn = connMySQL.open();
        PreparedStatement pstmt = conn.prepareStatement(sql);
    
        // Llenamos los valores de la consulta:
        pstmt.setString(1, String.valueOf(id));// El ID del producto que se actualizará
        
        // Ejecutamos la consulta:
        pstmt.executeUpdate();
    
        // Cerramos conexión:
        pstmt.close();
        conn.close();
    }
    
    public List<Producto> getAll(String filtro) throws Exception{
        String sql = "SELECT * FROM v_producto";
        ConexionMySQL connMySQL = new ConexionMySQL();
        Connection conn = connMySQL.open();
        PreparedStatement pstmt = conn.prepareStatement(sql);
        ResultSet rs = pstmt.executeQuery();
        List<Producto> productos = new ArrayList<>();
        
        while(rs.next())
            productos.add(fill(rs));
        
        rs.close();
        pstmt.close();
        conn.close();
        
        return productos;
    }
    
    private Producto fill(ResultSet rs) throws Exception{
        Producto p = new Producto();
        Categoria c = new Categoria();
        
        p.setId(rs.getInt("idProducto"));
        p.setNombre(rs.getString("nombre"));
        p.setPrecio(rs.getDouble("precio"));
        p.setCantidad(rs.getInt("cantidad"));
        p.setEstatus(rs.getInt("estatus"));
        
        c.setId(rs.getInt("Id"));
        c.setDescripcion(rs.getString("Categoria"));
        c.setEstatus(rs.getInt("Est"));
        
        p.setCategoria(c);
        
        return p;
    }
}