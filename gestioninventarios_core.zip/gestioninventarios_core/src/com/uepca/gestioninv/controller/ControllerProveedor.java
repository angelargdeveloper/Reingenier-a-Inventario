package com.uepca.gestioninv.controller;


import com.uepca.gestioninv.db.ConexionMySQL;
import com.uepca.gestioninv.model.Proveedor;
import java.util.List;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;

/**
 *
 * @author D_Ale
 */
public class ControllerProveedor {
    public int insert(Proveedor p) throws Exception{
        String sql ="INSERT INTO proveedor(nombre,razonSocial,rfc,email,telefonoFijo,telefonoMovil)"
                + "VALUES(?,?,?,?,?,?);";
        ConexionMySQL connMuSQL = new ConexionMySQL();
        Connection conn = connMuSQL.open();
        PreparedStatement pstmt = conn.prepareStatement(sql,PreparedStatement.RETURN_GENERATED_KEYS);
        ResultSet rs = null;
        
        //Llenamos los valores de la consulta:
        pstmt.setString(1, p.getNombre());
        pstmt.setString(2, p.getRazonSocial());
        pstmt.setString(3, p.getRfc());
        pstmt.setString(4, p.getEmail());
        pstmt.setString(5, p.getFijo());
        pstmt.setString(6, p.getMovil());
              
        //Ejecutamos la consulta:
        pstmt.executeUpdate();
        
        //Recuperamos el ID que se insertó:
        rs = pstmt.getGeneratedKeys();
        if(rs.next())
            p.setId(rs.getInt(1));
        
        //Cerramos conexion:
        rs.close();
        pstmt.close();
        conn.close();
        
        return p.getId();
    }
    
    public void update(Proveedor p)throws Exception{
        String sql = "UPDATE proveedor SET nombre=?, razonSocial=?, rfc=?, email=?, telefonoFijo=?,"
                + "telefonoMovil=? WHERE idProveedor=?";
        ConexionMySQL connMySQL = new ConexionMySQL();
        Connection conn = connMySQL.open();
        PreparedStatement pstmt = conn.prepareStatement(sql);
    
        // Llenamos los valores de la consulta:
        pstmt.setString(1, p.getNombre());
        pstmt.setString(2, p.getRazonSocial());
        pstmt.setString(3, p.getRfc());
        pstmt.setString(4, p.getEmail());
        pstmt.setString(5, p.getFijo());
        pstmt.setString(6, p.getMovil());
        pstmt.setInt(7, p.getId());// El ID del proveedor que se actualizará
    
        // Ejecutamos la consulta:
        pstmt.executeUpdate();
    
        // Cerramos conexión:
        pstmt.close();
        conn.close();
    }
    
    public void softDelete(Proveedor p) throws Exception
    {
        String sql = "UPDATE proveedor SET estatus = ? WHERE idProveedor = ?";
        ConexionMySQL connMySQL = new ConexionMySQL();
        Connection conn = connMySQL.open();
        PreparedStatement pstmt = conn.prepareStatement(sql);

        // Establecemos los valores de los parámetros para la actualización
        pstmt.setInt(1, 0);
        pstmt.setInt(2, p.getId());
        
        // Ejecutamos la consulta
        pstmt.executeUpdate();

        // Cerramos conexión
        pstmt.close();
        conn.close();
        
    }
    
    public List<Proveedor> getAll(String filtro) throws Exception{
        String sql = "SELECT * FROM proveedor";
        ConexionMySQL connMySQL = new ConexionMySQL();
        Connection conn = connMySQL.open();
        PreparedStatement pstmt = conn.prepareStatement(sql);
        ResultSet rs = pstmt.executeQuery();
        List<Proveedor> vendedor = new ArrayList<>();
        
        while(rs.next())
            vendedor.add(fill(rs));
        
        rs.close();
        pstmt.close();
        conn.close();
        
        return vendedor;
    }
    
    private Proveedor fill(ResultSet rs) throws Exception{
        Proveedor p = new Proveedor();
        p.setId(rs.getInt("idProveedor"));
        p.setNombre(rs.getString("nombre"));
        p.setRazonSocial(rs.getString("razonSocial"));
        p.setRfc(rs.getString("rfc"));
        p.setEmail(rs.getString("email"));
        p.setFijo(rs.getString("telefonoFijo"));
        p.setMovil(rs.getString("telefonoMovil"));   
        p.setEstatus(rs.getInt("estatus"));
               
        return p;
    }

}
