package com.uepca.gestioninv.controller;

import com.uepca.gestioninv.db.ConexionMySQL;
import com.uepca.gestioninv.model.Area;
import com.uepca.gestioninv.model.Empleado;
import java.util.List;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;

/**
 *
 * @author D_Ale
 */
public class ControllerEmpleado {
    public int insert(Empleado e) throws Exception{
        String sql ="INSERT INTO empleado(nombre,fechaAlta,fechaNac,direccion,poblacion,codPostal,telefono,idArea)"
                + "VALUES(?,?,?,?,?,?,?,?);";
        ConexionMySQL connMuSQL = new ConexionMySQL();
        Connection conn = connMuSQL.open();
        PreparedStatement pstmt = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
        ResultSet rs = null;

        // Llenamos los valores de la consulta:
        pstmt.setString(1, e.getNombre());
        pstmt.setString(2, e.getFechaAlta());
        pstmt.setString(3, e.getFechaNac());
        pstmt.setString(4, e.getDireccion());
        pstmt.setString(5, e.getPoblacion());
        pstmt.setString(6, e.getCodPostal());
        pstmt.setString(7, e.getTelefono());

        // Verificamos si el área del empleado no es null antes de intentar acceder a su ID
        if (e.getArea()!= null) {
            pstmt.setInt(8, e.getArea().getId());
        } else {
            // Manejar la situación de que el área es null, por ejemplo, lanzar una excepción
            throw new Exception("El área del empleado no está asignada.");
        }

        // Ejecutamos la consulta:
        pstmt.executeUpdate();

        // Recuperamos el ID que se insertó:
        rs = pstmt.getGeneratedKeys();
        if (rs.next())
            e.setId(rs.getInt(1));

        // Cerramos conexion:
        rs.close();
        pstmt.close();
        conn.close();

    return e.getId();

    }
    
    public void update(Empleado e)throws Exception{
        String sql = "UPDATE empleado SET nombre=?, fechaAlta=?, fechaNac=?, direccion=?, poblacion=?,"
                + "codPostal=?, telefono=?, idArea=? WHERE idEmpleado=?";
        ConexionMySQL connMySQL = new ConexionMySQL();
        Connection conn = connMySQL.open();
        PreparedStatement pstmt = conn.prepareStatement(sql);
    
        // Llenamos los valores de la consulta:
        pstmt.setString(1, e.getNombre());
        pstmt.setString(2, e.getFechaAlta());
        pstmt.setString(3, e.getFechaNac());
        pstmt.setString(4, e.getDireccion());
        pstmt.setString(5, e.getPoblacion());
        pstmt.setString(6, e.getCodPostal());
        pstmt.setString(7, e.getTelefono());
        pstmt.setInt(8, e.getArea().getId());
        pstmt.setInt(9, e.getId());// El ID del empleado que se actualizará
    
        // Ejecutamos la consulta:
        pstmt.executeUpdate();
    
        // Cerramos conexión:
        pstmt.close();
        conn.close();

    }
    
    public void softDelete(Empleado e) throws Exception{
        String sql = "UPDATE empleado SET estatus = ? WHERE idEmpleado = ?";
        ConexionMySQL connMySQL = new ConexionMySQL();
        Connection conn = connMySQL.open();
        PreparedStatement pstmt = conn.prepareStatement(sql);

        // Establecemos los valores de los parámetros para la actualización
        pstmt.setInt(1, 0);
        pstmt.setInt(2, e.getId());
        
        // Ejecutamos la consulta
        pstmt.executeUpdate();

        // Cerramos conexión
        pstmt.close();
        conn.close();

    }
    
    public List<Empleado> getAll(String filtro) throws Exception{
        String sql = "SELECT * FROM v_empleado";
        ConexionMySQL connMySQL = new ConexionMySQL();
        Connection conn = connMySQL.open();
        PreparedStatement pstmt = conn.prepareStatement(sql);
        ResultSet rs = pstmt.executeQuery();
        List<Empleado> empleado = new ArrayList<>();
        
        while(rs.next())
            empleado.add(fill(rs));
        
        rs.close();
        pstmt.close();
        conn.close();
        
        return empleado;
    }
    
    private Empleado fill(ResultSet rs) throws Exception{
        Empleado e = new Empleado();
        Area a = new Area();
        e.setId(rs.getInt("idEmpleado"));
        e.setNombre(rs.getString("nombre"));
        e.setFechaAlta(rs.getString("fechaAlta"));
        e.setFechaNac(rs.getString("fechaNac"));
        e.setDireccion(rs.getString("direccion"));
        e.setPoblacion(rs.getString("poblacion"));
        e.setCodPostal(rs.getString("codPostal"));
        e.setTelefono(rs.getString("telefono"));
       
        a.setId(rs.getInt("Id"));
        a.setDescripcion(rs.getString("Area"));
        a.setEstatus(rs.getInt("AEst"));
        
        e.setEstatus(rs.getInt("estatus"));
        e.setArea(a);
        
        return e;
    }
}
