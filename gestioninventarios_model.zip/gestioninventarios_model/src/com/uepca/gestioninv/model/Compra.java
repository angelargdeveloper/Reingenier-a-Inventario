package com.uepca.gestioninv.model;


//import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
public class Compra
{
    int id;
    String nombreProveedor;
    String nombreProducto;
    double precioUnitario;
    int kilos;
    double descuento;
    String fecha;
    double precioCompra;
    Proveedor proveedor;
    Producto producto;
    int estatus;
    List<DetalleVenta> detalleCompras;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombreProveedor() {
        return nombreProveedor;
    }

    public void setNombreProveedor(String nombreProveedor) {
        this.nombreProveedor = nombreProveedor;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(float precioUnitario) {
        this.precioUnitario = precioUnitario;
    }
    
    

    public int getKilos() {
        return kilos;
    }

    public void setKilos(int kilos) {
        this.kilos = kilos;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(float descuento) {
        this.descuento = descuento;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public double getPrecioCompra() {
        return precioCompra;
    }

    public void setPrecioCompra(float precioCompra) {
        this.precioCompra = precioCompra;
    }
      
    public Proveedor getProveedor() {
        return proveedor;
    }

    public void setProveedor(Proveedor proveedor) {
        this.proveedor = proveedor;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public int getEstatus() {
        return estatus;
    }

    public void setEstatus(int estatus) {
        this.estatus = estatus;
    }

    public List<DetalleVenta> getDetalleCompras() {
        return detalleCompras;
    }

    public void setDetalleCompras(List<DetalleVenta> detalleCompras) {
        this.detalleCompras = detalleCompras;
    }
    
    public Compra() {
        detalleCompras = new ArrayList<>(); // Inicializa la lista de detalles de compra
    }
}

