package com.uepca.gestioninv.model;

/**
 *
 * @author D_Ale
 */
public class Proveedor {
    int id;
    String nombre;
    String razonSocial;
    String rfc;
    String email;
    String tFijo;
    String tMovil;
    int estatus;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRazonSocial() {
        return razonSocial;
    }

    public void setRazonSocial(String razonSocial) {
        this.razonSocial = razonSocial;
    }

    public String getRfc() {
        return rfc;
    }

    public void setRfc(String rfc) {
        this.rfc = rfc;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFijo() {
        return tFijo;
    }

    public void setFijo(String tFijo) {
        this.tFijo = tFijo;
    }

    public String getMovil() {
        return tMovil;
    }

    public void setMovil(String tMovil) {
        this.tMovil = tMovil;
    }

    public int getEstatus() {
        return estatus;
    }

    public void setEstatus(int estatus) {
        this.estatus = estatus;
    }

    
}
