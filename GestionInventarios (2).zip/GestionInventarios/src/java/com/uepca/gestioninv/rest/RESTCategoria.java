package com.uepca.gestioninv.rest;


import com.uepca.gestioninv.controller.ControllerCategoria;
import com.uepca.gestioninv.model.Categoria;
import com.google.gson.Gson;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
/**
 *
 * @author D_Ale
 */

@Path("categoria")
public class RESTCategoria {
    @GET
    @Path("getAll")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAll(@QueryParam("filtro") @DefaultValue("") String filtro){
        String out = null;
        ControllerCategoria cc = new ControllerCategoria();
        List<Categoria> categorias = null;
        Gson gson = new Gson();
        try {
           categorias = cc.getAll(filtro);
           out = gson.toJson(categorias);
        } catch (Exception e) {
            e.printStackTrace();
            out = """
                  {
                    "exception":"%s"
                  }
                  """;
            
            out = String.format(out, e.toString().replaceAll("\"", ""));
        }
        return Response.ok(out).build();
    }
    
    @POST
    @Path("save")
    @Produces(MediaType.APPLICATION_JSON)
    public Response save(@FormParam("categoria") String datosCategoria){
        String out = null;
        ControllerCategoria cc = new ControllerCategoria();
        Gson gson = new Gson();
        Categoria c = null;
        try {
            c = gson.fromJson(datosCategoria, Categoria.class);
            if(c == null)
                out = "{\"error\";\"No se proporcionaron datos de la categoría.\"}";
            else if(c.getId() == 0)
                cc.insert(c);
            else
                cc.update(c);
            out = new Gson().toJson(c);
        } catch (Exception ex) {
            ex.printStackTrace();
            out ="""
                 {
                    "exception":"%s"
                 }
                 """;
            out = String.format(out, ex.toString().replaceAll("\"", ""));
        }
        return Response.ok(out).build();
    }
    
    @POST
    @Path("softdelete")
    @Produces(MediaType.APPLICATION_JSON)
    public Response softDelete(@FormParam("categoria") String datosCategoria)
    {
        String out = null;
        ControllerCategoria cc = new ControllerCategoria();
        Gson gson = new Gson();
        Categoria c = null;
        try
        {
            c = gson.fromJson(datosCategoria, Categoria.class);
            if(c == null)
                out = "{\"error\":\"No se proporcionaron datos de la categoria.\"}";
            else
                cc.delete(c);
            out = new Gson().toJson(c);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            out = """
                  {
                    "exception":"%s"
                  }
                  """;
            out = String.format(out, ex.toString().replaceAll("\"", ""));
        }
        return Response.ok(out).build();
    }
}
