package com.uepca.gestioninv.rest;

import com.google.gson.Gson;
import com.uepca.gestioninv.controller.ControllerProveedor;
import com.uepca.gestioninv.model.Proveedor;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
/**
 *
 * @author D_Ale
 */
@Path("proveedor")
public class RESTProveedor {
    @GET
    @Path("getAll")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAll(@QueryParam("filtro") @DefaultValue("") String filtro){
        
        String out = null;
        List<Proveedor> proveedores = null;
        ControllerProveedor cp = new ControllerProveedor();
        Gson gson = new Gson();
        
        try 
        {
            proveedores = cp.getAll(filtro);
            out = gson.toJson(proveedores);
        } catch (Exception e) 
        {
            e.printStackTrace();
            out = """
                  {
                    "exception":"%s"
                  }
                  """;
            out = String.format(out, e.toString().replaceAll("\"", ""));
        }
        return Response.ok(out).build();
    }
    
    @POST
    @Path("save")
    @Produces(MediaType.APPLICATION_JSON)
    public Response save(@FormParam("proveedor") String datosProveedor){
        String out = null;
        ControllerProveedor cp = new ControllerProveedor();
        Gson gson = new Gson();
        Proveedor p = null;
        try {
            p = gson.fromJson(datosProveedor, Proveedor.class);
            if(p == null)
                out = "{\"error\";\"No se proporcionaron datos del proveedor.\"}";
            else if(p.getId() == 0)
                cp.insert(p);
            else
                cp.update(p);
            out = new Gson().toJson(p);
        } catch (Exception e) {
            e.printStackTrace();
            out ="""
                 {
                    "exception":"%s"
                 }
                 """;
            out = String.format(out, e.toString().replaceAll("\"", ""));
        }
        return Response.ok(out).build();
    }
    
    @POST
    @Path("softdelete")
    @Produces(MediaType.APPLICATION_JSON)
    public Response softDelete(@FormParam("proveedor") String datosCompra)
    {
        String out = null;
        ControllerProveedor cc = new ControllerProveedor();
        Gson gson = new Gson();
        Proveedor p= null;
        try
        {
            p = gson.fromJson(datosCompra, Proveedor.class);
            if(p == null)
                out = "{\"error\":\"No se proporcionaron datos del proveedor.\"}";
            else
                cc.softDelete(p);
            out = new Gson().toJson(p);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            out = """
                  {
                    "exception":"%s"
                  }
                  """;
            out = String.format(out, e.toString().replaceAll("\"", ""));
        }
        return Response.ok(out).build();
    }
}
