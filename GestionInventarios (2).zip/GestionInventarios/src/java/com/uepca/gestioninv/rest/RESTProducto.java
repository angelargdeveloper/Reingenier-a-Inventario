package com.uepca.gestioninv.rest;

import com.google.gson.Gson;
import com.uepca.gestioninv.controller.ControllerProducto;
import com.uepca.gestioninv.model.Producto;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

/**
 *
 * @author D_Ale
 */
@Path("producto")
public class RESTProducto {
    @GET
    @Path("getAll")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAll(@QueryParam("filtro") @DefaultValue("") String filtro){
        
        String out = null;
        List<Producto> productos = null;
        ControllerProducto cp = new ControllerProducto();
        Gson gson = new Gson();
        
        try 
        {
            productos = cp.getAll(filtro);
            out = gson.toJson(productos);
        } catch (Exception e) 
        {
            e.printStackTrace();
            out = """
                  {
                    "exception":"%s"
                  }
                  """;
            out = String.format(out, e.toString().replaceAll("\"", ""));
        }
        return Response.ok(out).build();
    }
    
    @POST
    @Path("save")
    @Produces(MediaType.APPLICATION_JSON)
    public Response save(@FormParam("producto") String datosProducto){
        String out = null;
        ControllerProducto cp = new ControllerProducto();
        Gson gson = new Gson();
        Producto p = null;
        try {
            p = gson.fromJson(datosProducto, Producto.class);
            if(p == null)
                out = "{\"error\";\"No se proporcionaron datos del producto.\"}";
            else if(p.getId() == 0)
                cp.insert(p);
            else
                cp.update(p);
            out = new Gson().toJson(p);
        } catch (Exception e) {
            e.printStackTrace();
            out ="""
                 {
                    "exception":"%s"
                 }
                 """;
            out = String.format(out, e.toString().replaceAll("\"", ""));
        }
        return Response.ok(out).build();
    }
    
    @POST
    @Path("borrar")
    @Produces(MediaType.APPLICATION_JSON)
    public Response borrar(@FormParam("producto") String id){
        String out = null;
        ControllerProducto cp = new ControllerProducto();
        Gson gson = new Gson();
        Producto p = null;
        try {
            p = gson.fromJson(id, Producto.class);
            if(p == null)
                out = "{\"error\";\"No se proporcionaron datos del producto.\"}";
            else if(p.getId() != 0)
                cp.delete(p.getId());
            
            out = new Gson().toJson(p);
        } catch (Exception e) {
            e.printStackTrace();
            out ="""
                 {
                    "exception":"%s"
                 }
                 """;
            out = String.format(out, e.toString().replaceAll("\"", ""));
        }
        return Response.ok(out).build();
    }
}
