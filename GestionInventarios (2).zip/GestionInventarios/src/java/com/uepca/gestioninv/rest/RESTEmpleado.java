package com.uepca.gestioninv.rest;

import com.google.gson.Gson;
import com.uepca.gestioninv.controller.ControllerEmpleado;
import com.uepca.gestioninv.model.Empleado;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
/**
 *
 * @author D_Ale
 */
@Path("empleado")
public class RESTEmpleado {
    @GET
    @Path("getAll")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAll(@QueryParam("filtro") @DefaultValue("") String filtro){
        
        String out = null;
        List<Empleado> vendedor = null;
        ControllerEmpleado cp = new ControllerEmpleado();
        Gson gson = new Gson();
        
        try 
        {
            vendedor = cp.getAll(filtro);
            out = gson.toJson(vendedor);
        } catch (Exception e) 
        {
            e.printStackTrace();
            out = """
                  {
                    "exception":"%s"
                  }
                  """;
            out = String.format(out, e.toString().replaceAll("\"", ""));
        }
        return Response.ok(out).build();
    }
    
    @POST
    @Path("save")
    @Produces(MediaType.APPLICATION_JSON)
    public Response save(@FormParam("empleado") String datosEmpleado){
        String out = null;
        ControllerEmpleado cp = new ControllerEmpleado();
        Gson gson = new Gson();
        Empleado e = null;
        try {
            e = gson.fromJson(datosEmpleado, Empleado.class);
            if(e == null)
                out = "{\"error\";\"No se proporcionaron datos del empleado.\"}";
            else if(e.getId() == 0)
                cp.insert(e);
            else
                cp.update(e);
            out = new Gson().toJson(e);
        } catch (Exception ex) {
            ex.printStackTrace();
            out ="""
                 {
                    "exception":"%s"
                 }
                 """;
            out = String.format(out, ex.toString().replaceAll("\"", ""));
        }
        return Response.ok(out).build();
    }
    
    @POST
    @Path("softdelete")
    @Produces(MediaType.APPLICATION_JSON)
    public Response softDelete(@FormParam("empleado") String datosEmpleado)
    {
        String out = null;
        ControllerEmpleado ce = new ControllerEmpleado();
        Gson gson = new Gson();
        Empleado e = null;
        try
        {
            e = gson.fromJson(datosEmpleado, Empleado.class);
            if(e == null)
                out = "{\"error\":\"No se proporcionaron datos del empleado.\"}";
            else
                ce.softDelete(e);
            out = new Gson().toJson(e);
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            out = """
                  {
                    "exception":"%s"
                  }
                  """;
            out = String.format(out, ex.toString().replaceAll("\"", ""));
        }
        return Response.ok(out).build();
    }
}
