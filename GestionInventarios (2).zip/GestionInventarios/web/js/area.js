let areas = [];

export async function inicializarModulo()
{
    setDetalleAreaVisible(false);
    consultarAreas();
}

async function consultarAreas()
{
    let url = "api/area/getAll";// Declara una variable llamada 'url' y la inicializa 
    //                              con la URL de la API para obtener todos los grupos
    let resp = await fetch(url);// Realiza una solicitud de búsqueda de recursos a 
    //                              la URL especificada y espera la respuesta.
    let datos = await resp.json();// Lee el cuerpo de la respuesta como JSON.
    
    if(datos.error != null)// Comprueba si hay un error en los datos obtenidos.
    {
        Swal.fire("", "Error al consultar areas", "warning"); // Muestra un mensaje de alerta al usuario.
        return; // Retorna y sale de la función.
    }
    if (datos.exception != null) // Comprueba si hay una excepción en los datos obtenidos.
    {
        Swal.fire("", datos.exception, "danger"); // Muestra un mensaje de alerta al usuario con la excepción obtenida.
        return; // Retorna y sale de la función.
    }
    areas = datos; // Asigna los datos obtenidos a la variable 'areas'.
    fillTableAreas(); // Llama a la función 'fillTableAreas'.
}

function fillTableAreas() // Declara una función llamada 'fillTableProductos'.
{
    let contenido = ''; // Declara una variable llamada 'contenido' e inicializa su valor como una cadena vacía.
    for (let i = 0; i < areas.length; i++) // Inicia un bucle que itera sobre todos los elementos del arreglo 'productos'.
    {
        if(areas[i].estatus === 1){
        contenido +=    '<tr>' + // Concatena una fila HTML al contenido.
                            '<td>' + areas[i].id +        '</td>'+
                            '<td>' + areas[i].descripcion + '</td>' + // Concatena una celda con el nombre del producto al contenido.
                            '<td>' + areas[i].estatus + '</td>' + 
                            '<td>' +  '<a href="#" onclick="cm.mostrarDetalleArea('+i+');"<button>hla</button></a>'+'</td>'+
                        '</tr>';
            }


    }
    document.getElementById("tbodyAreas").innerHTML = contenido; // Establece el contenido HTML generado dentro del elemento con ID 'tbodyProductos'.
}

export function setDetalleAreaVisible(valor)
{
    if(valor)
    {
        document.getElementById("divDetalleArea").style.display='';
        document.getElementById("divCatalogoArea").style.display='none';
    }
    else
    {
        document.getElementById("divDetalleArea").style.display='none';
        document.getElementById("divCatalogoArea").style.display='';
    }
}

export function mostrarDetalleArea(pos)
{
    let a = area[pos];
    setDetalleAreaVisible(true);
    
    document.getElementById("txtIdArea").value = a.id;
    document.getElementById("txtNombre").value = a.descripcion;
  
}

export function limpiarFormulario()
{
    document.getElementById("txtIdArea").value = "";
    document.getElementById("txtNombre").value = "";
}

export async function save(){
    let url='api/area/save';
    let area = new Object();
    let params = null;//parametros del servicio
    let resp = null;//respuesta del servicio
    let datos = null;//datos JSON de respuesta
    let ctype = 'application/x-www-form-urlencoded;charset=UTF-8';//tipo del documento
    
    //Revisamon si hay un ID de producto:
    if(document.getElementById("txtIdArea").value.trim().length === 0)
        area.id = 0;
    else
        area.id = parseInt(document.getElementById("txtIdArea").value.trim());
    
    area.descripcion = document.getElementById("txtNombre").value;
    
    params  = {
                area : JSON.stringify(area)
    };
    
    resp = await fetch(url,
                        {
                            method:"POST",
                            headers:{'Content-Type' : ctype},
                            body : new URLSearchParams(params)
                        });
    datos = await resp.json();
    
    if (datos.error != null)
    {
        Swal.fire("", "Error al guardar area", "warning");
        return;
    }
    
    if (datos.exception != null)
    {
        Swal.fire("", datos.exception, "danger");
        return;
    }
    
    document.getElementById("txtIdArea").value = datos.id;
    /*Swal.fire('Movimiento realizado.', 
              'Datos del area guardados', 
              'success');*/
    //consultarProductos();
}

export async function borrar(){
    let url='api/area/softdelete';
    let area = new Object();
    let params = null;//parametros del servicio
    let resp = null;//respuesta del servicio
    let datos = null;//datos JSON de respuesta
    let ctype = 'application/x-www-form-urlencoded;charset=UTF-8';//tipo del documento
    
    //Revisamon si hay un ID de producto:
    if(document.getElementById("txtIdArea").value.trim().length === 0)
        area.id = 0;
    else
        area.id = parseInt(document.getElementById("txtIdArea").value.trim());
    
    
    
    
    params  = {
                area : JSON.stringify(area)
    };
    
    resp = await fetch(url,
                        {
                            method:"POST",
                            headers:{'Content-Type' : ctype},
                            body : new URLSearchParams(params)
                        });
    datos = await resp.json();
    
    if (datos.error != null)
    {
        Swal.fire("", "Error al borrar el area", "warning");
        return;
    }
    
    if (datos.exception != null)
    {
        Swal.fire("", datos.exception, "danger");
        return;
    }
    
    document.getElementById("txtIdArea").value = datos.id;
    /*Swal.fire('Movimiento realizado.', 
              'Producto eliminado', 
              'success');
    consultarProductos();*/
}


