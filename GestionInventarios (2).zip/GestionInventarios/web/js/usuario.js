let usuario= [];
let empleado =[];

export async function inicializarModulo()
{
    setDetalleUsuarioVisible(false);
    consultarUsuario();
    consultaEmpleado();
}

async function consultaEmpleado()
{
    let url = "api/empleado/getAll";
    let resp = await fetch(url);
    let datos = await resp.json();
    
    if (datos.error != null)
    {
        Swal.fire("", "Error al consultar empleados", "warning");
        return;
    }
    
    if (datos.exception != null)
    {
        Swal.fire("", datos.exception, "danger");
        return;
    }
    
    empleado = datos;
    fillComboBoxEmpleado();
}

function fillComboBoxEmpleado()
{
    let contenido = '';
    for (let i = 0; i < empleado.length; i++)
    {
        if(empleado[i].estatus == 1){
            contenido += '<option value="' + empleado[i].id + '">' +
                                         empleado[i].nombre +
                     '</option>';
        }
    }
    document.getElementById('cmbEmpleado').innerHTML = contenido;
}

export async function save()
{
    let url = 'api/usuario/save';
    let usuario = new Object();
    let params = null; //Parametros del Servicio
    let resp = null; //Respuesta del Servicio
    let datos = null; //Datos JSON de respuesta
    let ctype = 'application/x-www-form-urlencoded;charset=UTF-8';
    
    //Revisamos si hay un ID de producto:
    if (document.getElementById("txtIdUsuario").value.trim().length === 0)
        usuario.id = 0;
    else
        usuario.id = parseInt(document.getElementById("txtIdUsuario").value.trim());
    
    usuario.usuario = document.getElementById("txtUsuario").value;
    usuario.pass = document.getElementById("txtPass").value;
    
    
    usuario.empleado = new Object();
    usuario.empleado.id = parseInt(document.getElementById("cmbEmpleado").value);
    
    console.log(usuario);
    params = {
                usuario : JSON.stringify(usuario)
             };
             
    resp = await fetch( url, 
                        {   method:"POST",
                            headers:{'Content-Type': ctype},
                            body: new URLSearchParams(params)
                        });
    datos = await resp.json();
    
    if (datos.error != null)
    {
        Swal.fire("", "Error al guardar Vendedor.", "warning");
        return;
    }
    
    if (datos.exception != null)
    {
        Swal.fire("", datos.exception, "danger");
        return;
    }
    
    //Si llegamos hasta aqui, significa que todo salio bien :)
    document.getElementById("txtIdUsuario").value = datos.id;
    /*Swal.fire('Movimiento realizado.', 
              'Datos de Vendedor guardados.', 
              'success');*/
    consultarUsuario();
}


export async function softDelete() // Declara una función asíncrona llamada 'save' y la exporta como parte del módulo.
{
    let url = 'api/usuario/borrar'; // Declara una variable llamada 'url' y la inicializa con la URL de la API para guardar productos.
    let usuario = new Object(); // Declara una variable llamada 'producto' y la inicializa como un objeto vacío.
    let params = null; // Declara una variable llamada 'params' y la inicializa como nula. Se utilizará para los parámetros del servicio.
    let resp = null; // Declara una variable llamada 'resp' y la inicializa como nula. Se utilizará para la respuesta del servicio.
    let datos = null; // Declara una variable llamada 'datos' y la inicializa como nula. Se utilizará para los datos JSON de respuesta.
    let ctype = 'application/x-www-form-urlencoded;charset=UTF-8'; // Declara una variable llamada 'ctype' y la inicializa con el tipo de documento.
    
    // Revisamos si hay un ID de producto:
    if(document.getElementById("txtIdUsuario").value.trim().length === 0) // Comprueba si el campo de ID del producto está vacío.
        usuario.id = 0; // Establece el ID del producto como 0.
    else
        usuario.id = parseInt(document.getElementById("txtIdUsuario").value.trim()); // Convierte y asigna el ID del producto como un entero.
    
        
    params = { // Asigna los parámetros para la solicitud al servicio.
                usuario : JSON.stringify(usuario) // Convierte el objeto 'producto' a una cadena JSON y lo asigna como un parámetro llamado 'producto'.
             };
    resp = await fetch(url, // Realiza una solicitud a la URL especificada.
                       { method:"POST", // Utiliza el método POST para la solicitud.
                         headers:{'Content-Type': ctype}, // Establece el tipo de contenido de la solicitud.
                         body: new URLSearchParams(params) // Codifica los parámetros como datos de formulario URL-encoded y los asigna al cuerpo de la solicitud.
                       });
    datos = await resp.json(); // Lee el cuerpo de la respuesta como JSON.
    
    if (datos.error != null) // Comprueba si hay un error en los datos obtenidos.
    {
        Swal.fire("", "Error al borrar Usuario", "warning"); // Muestra un mensaje de alerta al usuario.
        return; // Retorna y sale de la función.
    }
    
    if (datos.exception != null) // Comprueba si hay una excepción en los datos obtenidos.
    {
        Swal.fire("", datos.exception, "danger"); // Muestra un mensaje de alerta al usuario con la excepción obtenida.
        return; // Retorna y sale de la función.
    }
    
    // Si llegamos hasta aquí, significa que todo salió bien.
    document.getElementById("txtIdUsuario").value = datos.id; // Asigna el ID del producto obtenido a un campo de entrada en el formulario.
    
    /*Swal.fire('Movimiento realizado.', // Muestra una notificación con un mensaje de éxito.
              'Datos de producto eliminados ' + JSON.stringify(usuario), 
              'success');*/
    consultarUsuario(); // Llama a la función 'consultarProductos'.
}

async function consultarUsuario()
{
    let url = "api/usuario/getAll";
    let resp = await fetch(url);
    let datos = await resp.json();
    
    if (datos.error != null)
    {
        Swal.fire("", "Error al consultar usuario", "warning");
        return;
    }
    
    if (datos.exception != null)
    {
        Swal.fire("", datos.exception, "danger");
        return;
    }
    
    usuario = datos;
    fillTableUsuario();
}

function fillTableUsuario()
{
    let contenido = '';
    for (let i = 0; i < usuario.length; i++)
    {
        if(usuario[i].estatus === 1)
        {
        contenido +=    '<tr>' +
                            '<td>' + usuario[i].id + '</td>' +
                            '<td>' + usuario[i].usuario + '</td>' +
                            '<td>' + usuario[i].pass + '</td>' +
                            '<td>' + usuario[i].empleado.nombre + '</td>' +
                            '<td>' + usuario[i].estatus + '</td>' +
                            '<td>' +  '<a href="#" onclick="cm.mostrarDetalleUsuario('+i+');"<i class="fas fa-pen text-info"></i></a>'+'</td>'+
                        '</tr>';
        }
    }
    document.getElementById("tbodyUsuario").innerHTML = contenido;
}

export function setDetalleUsuarioVisible(valor)
{
    if(valor)
    {
        document.getElementById("divDetalleUsuario").style.display='';
        document.getElementById("divCatalogoUsuario").style.display='none';
    }
    else
    {
        document.getElementById("divDetalleUsuario").style.display='none';
        document.getElementById("divCatalogoUsuario").style.display='';
    }
}

export function mostrarDetalleUsuario(pos)
{
    let u = usuario[pos];
    setDetalleUsuarioVisible(true);
    
    document.getElementById("txtIdUsuario").value = u.id;
    document.getElementById("txtUsuario").value = u.usuario;
    document.getElementById("txtPass").value = u.pass;
    document.getElementById("cmbEmpleado").value = u.empleado.nombre;
    
}

export function limpiarFormulario()
{
    document.getElementById("txtIdUsuario").value = "";
    document.getElementById("txtUsuario").value = "";
    document.getElementById("txtPass").value = "";
    document.getElementById("cmbEmpleado").value = "";
}


