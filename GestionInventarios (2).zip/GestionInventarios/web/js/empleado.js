let empleado= [];
let area =[];

export async function inicializarModulo()
{
    setDetalleEmpleadoVisible(false);
    consultarEmpleado();
    consultarArea();
}

async function consultarArea()
{
    let url = "api/area/getAll";
    let resp = await fetch(url);
    let datos = await resp.json();
    
    if (datos.error != null)
    {
        Swal.fire("", "Error al consultar areas", "warning");
        return;
    }
    
    if (datos.exception != null)
    {
        Swal.fire("", datos.exception, "danger");
        return;
    }
    
    area = datos;
    fillComboBoxArea();
}

function fillComboBoxArea()
{
    let contenido = '';
    for (let i = 0; i < area.length; i++)
    {
        contenido += '<option value="' + area[i].id + '">' +
                                         area[i].descripcion +
                     '</option>';
    }
    document.getElementById('cmbArea').innerHTML = contenido;
}

export async function save()
{
    let url = 'api/empleado/save';
    let empleado = new Object();
    let params = null; //Parametros del Servicio
    let resp = null; //Respuesta del Servicio
    let datos = null; //Datos JSON de respuesta
    let ctype = 'application/x-www-form-urlencoded;charset=UTF-8';
    
    //Revisamos si hay un ID de producto:
    if (document.getElementById("txtIdEmpleado").value.trim().length === 0)
        empleado.id = 0;
    else
        empleado.id = parseInt(document.getElementById("txtIdEmpleado").value.trim());
    
    empleado.nombre = document.getElementById("txtNombre").value;
    empleado.fechaAlta = document.getElementById("txtFechaAlta").value;
    empleado.fechaNac = document.getElementById("txtFechaNac").value;
    empleado.direccion = document.getElementById("txtDireccion").value;
    empleado.poblacion = document.getElementById("txtPoblacion").value;
    empleado.codPostal = document.getElementById("txtCodPostal").value;
    empleado.telefono = document.getElementById("txtTelefono").value;
    
    empleado.area = new Object();
    empleado.area.id = parseInt(document.getElementById("cmbArea").value);
    
    params = {
                empleado : JSON.stringify(empleado)
             };
             
    resp = await fetch( url, 
                        {   method:"POST",
                            headers:{'Content-Type': ctype},
                            body: new URLSearchParams(params)
                        });
    datos = await resp.json();
    
    if (datos.error != null)
    {
        Swal.fire("", "Error al guardar Vendedor.", "warning");
        return;
    }
    
    if (datos.exception != null)
    {
        Swal.fire("", datos.exception, "danger");
        return;
    }
    
    //Si llegamos hasta aqui, significa que todo salio bien :)
    document.getElementById("txtIdEmpleado").value = datos.id;
    /*Swal.fire('Movimiento realizado.', 
              'Datos de Vendedor guardados.', 
              'success');*/
    consultarEmpleado();
}


export async function softDelete() // Declara una función asíncrona llamada 'save' y la exporta como parte del módulo.
{
    let url = 'api/empleado/softdelete'; // Declara una variable llamada 'url' y la inicializa con la URL de la API para guardar productos.
    let empleado = new Object(); // Declara una variable llamada 'producto' y la inicializa como un objeto vacío.
    let params = null; // Declara una variable llamada 'params' y la inicializa como nula. Se utilizará para los parámetros del servicio.
    let resp = null; // Declara una variable llamada 'resp' y la inicializa como nula. Se utilizará para la respuesta del servicio.
    let datos = null; // Declara una variable llamada 'datos' y la inicializa como nula. Se utilizará para los datos JSON de respuesta.
    let ctype = 'application/x-www-form-urlencoded;charset=UTF-8'; // Declara una variable llamada 'ctype' y la inicializa con el tipo de documento.
    
    // Revisamos si hay un ID de producto:
    if(document.getElementById("txtIdEmpleado").value.trim().length === 0) // Comprueba si el campo de ID del producto está vacío.
        empleado.id = 0; // Establece el ID del producto como 0.
    else
        empleado.id = parseInt(document.getElementById("txtIdEmpleado").value.trim()); // Convierte y asigna el ID del producto como un entero.
    
        
    params = { // Asigna los parámetros para la solicitud al servicio.
                empleado : JSON.stringify(empleado) // Convierte el objeto 'producto' a una cadena JSON y lo asigna como un parámetro llamado 'producto'.
             };
    resp = await fetch(url, // Realiza una solicitud a la URL especificada.
                       { method:"POST", // Utiliza el método POST para la solicitud.
                         headers:{'Content-Type': ctype}, // Establece el tipo de contenido de la solicitud.
                         body: new URLSearchParams(params) // Codifica los parámetros como datos de formulario URL-encoded y los asigna al cuerpo de la solicitud.
                       });
    datos = await resp.json(); // Lee el cuerpo de la respuesta como JSON.
    
    if (datos.error != null) // Comprueba si hay un error en los datos obtenidos.
    {
        Swal.fire("", "Error al guardar Empleados", "warning"); // Muestra un mensaje de alerta al usuario.
        return; // Retorna y sale de la función.
    }
    
    if (datos.exception != null) // Comprueba si hay una excepción en los datos obtenidos.
    {
        Swal.fire("", datos.exception, "danger"); // Muestra un mensaje de alerta al usuario con la excepción obtenida.
        return; // Retorna y sale de la función.
    }
    
    // Si llegamos hasta aquí, significa que todo salió bien.
    document.getElementById("txtIdEmpleado").value = datos.id; // Asigna el ID del producto obtenido a un campo de entrada en el formulario.
    
    /*Swal.fire('Movimiento realizado.', // Muestra una notificación con un mensaje de éxito.
              'Datos de producto eliminados ' + JSON.stringify(empleado), 
              'success');*/
    consultarEmpleado(); // Llama a la función 'consultarProductos'.
}

async function consultarEmpleado()
{
    let url = "api/empleado/getAll";
    let resp = await fetch(url);
    let datos = await resp.json();
    
    if (datos.error != null)
    {
        Swal.fire("", "Error al consultar empleado", "warning");
        return;
    }
    
    if (datos.exception != null)
    {
        Swal.fire("", datos.exception, "danger");
        return;
    }
    
    empleado = datos;
    fillTableEmpleado();
}

function fillTableEmpleado()
{
    let contenido = '';
    for (let i = 0; i < empleado.length; i++)
    {
        if(empleado[i].estatus === 1)
        {
        contenido +=    '<tr>' +
                            '<td>' + empleado[i].id + '</td>' +
                            '<td>' + empleado[i].nombre + '</td>' +
                            '<td>' + empleado[i].fechaAlta + '</td>' +
                            '<td>' + empleado[i].fechaNac + '</td>' +
                            '<td>' + empleado[i].direccion + '</td>' +
                            '<td>' + empleado[i].poblacion + '</td>' +
                            '<td>' + empleado[i].codPostal + '</td>' +
                            '<td>' + empleado[i].telefono + '</td>' +
                            '<td>' + empleado[i].area.descripcion + '</td>' +
                            '<td>' + empleado[i].estatus + '</td>' +
                            '<td>' +  '<a href="#" onclick="cm.mostrarDetalleVendedor('+i+');"<i class="fas fa-pen text-info"></i></a>'+'</td>'+
                        '</tr>';
        }
    }
    document.getElementById("tbodyEmpleado").innerHTML = contenido;
}

export function setDetalleEmpleadoVisible(valor)
{
    if(valor)
    {
        document.getElementById("divDetalleEmpleado").style.display='';
        document.getElementById("divCatalogoEmpleado").style.display='none';
    }
    else
    {
        document.getElementById("divDetalleEmpleado").style.display='none';
        document.getElementById("divCatalogoEmpleado").style.display='';
    }
}

export function mostrarDetalleEmpleado(pos)
{
    let e = empleado[pos];
    setDetalleEmpleadorVisible(true);
    
    document.getElementById("txtIdVendedor").value = e.id;
    document.getElementById("txtNombre").value = e.nombre;
    document.getElementById("txtFechaAlta").value = e.fechaAlta;
    document.getElementById("txtFechaNac").value = e.fechaNac;
    document.getElementById("txtDireccion").value = e.direccion;
    document.getElementById("txtPoblacion").value = e.poblacion;
    document.getElementById("txtCodPostal").value = e.codPostal;
    document.getElementById("txtTelefono").value = e.telefono;
    document.getElementById("cmbEdoCivil").value = e.Area.descripcion;
    
}

export function limpiarFormulario()
{
    document.getElementById("txtIdEmpleado").value = "";
    document.getElementById("txtNombre").value = "";
    document.getElementById("txtFechaAlta").value = "";
    document.getElementById("txtFechaNac").value = "";
    document.getElementById("txtDireccion").value ="";
    document.getElementById("txtPoblacion").value = "";
    document.getElementById("txtCodPostal").value ="";
    document.getElementById("txtTelefono").value = "";
    document.getElementById("cmbArea").value = "";
}
