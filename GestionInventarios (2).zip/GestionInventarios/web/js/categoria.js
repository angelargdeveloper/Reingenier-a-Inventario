let categorias = [];

export async function inicializarModulo()
{
    setDetalleCategoriaVisible(false);
    consultarCategorias();
}

async function consultarCategorias()
{
    let url = "api/categoria/getAll";// Declara una variable llamada 'url' y la inicializa 
    //                              con la URL de la API para obtener todos los grupos
    let resp = await fetch(url);// Realiza una solicitud de búsqueda de recursos a 
    //                              la URL especificada y espera la respuesta.
    let datos = await resp.json();// Lee el cuerpo de la respuesta como JSON.
    
    if(datos.error != null)// Comprueba si hay un error en los datos obtenidos.
    {
        Swal.fire("", "Error al consultar categorias", "warning"); // Muestra un mensaje de alerta al usuario.
        return; // Retorna y sale de la función.
    }
    if (datos.exception != null) // Comprueba si hay una excepción en los datos obtenidos.
    {
        Swal.fire("", datos.exception, "danger"); // Muestra un mensaje de alerta al usuario con la excepción obtenida.
        return; // Retorna y sale de la función.
    }
    categorias = datos; // Asigna los datos obtenidos a la variable 'categorias'.
    fillTableCategorias(); // Llama a la función 'fillTableAreas'.
}

function fillTableCategorias() // Declara una función llamada 'fillTableProductos'.
{
    let contenido = ''; // Declara una variable llamada 'contenido' e inicializa su valor como una cadena vacía.
    for (let i = 0; i < categorias.length; i++) // Inicia un bucle que itera sobre todos los elementos del arreglo 'productos'.
    {
        if(categorias[i].estatus === 1){
        contenido +=    '<tr>' + // Concatena una fila HTML al contenido.
                            '<td>' + categorias[i].id +        '</td>'+
                            '<td>' + categorias[i].descripcion + '</td>' + // Concatena una celda con el nombre del producto al contenido.
                            '<td>' + categorias[i].estatus + '</td>' + 
                            '<td>' +  '<a href="#" onclick="cm.mostrarDetalleArea('+i+');"<button>hla</button></a>'+'</td>'+
                        '</tr>';
            }


    }
    document.getElementById("tbodyCategorias").innerHTML = contenido; // Establece el contenido HTML generado dentro del elemento con ID 'tbodyProductos'.
}

export function setDetalleCategoriaVisible(valor)
{
    if(valor)
    {
        document.getElementById("divDetalleCategoria").style.display='';
        document.getElementById("divCatalogoCategoria").style.display='none';
    }
    else
    {
        document.getElementById("divDetalleCategoria").style.display='none';
        document.getElementById("divCatalogoCategoria").style.display='';
    }
}

export function mostrarDetalleCategoria(pos)
{
    let c = categoria[pos];
    setDetalleCategoriaVisible(true);
    
    document.getElementById("txtIdCategoria").value = c.id;
    document.getElementById("txtNombre").value = c.descripcion;
  
}

export function limpiarFormulario()
{
    document.getElementById("txtIdCategoria").value = "";
    document.getElementById("txtNombre").value = "";
}

export async function save(){
    let url='api/categoria/save';
    let categoria = new Object();
    let params = null;//parametros del servicio
    let resp = null;//respuesta del servicio
    let datos = null;//datos JSON de respuesta
    let ctype = 'application/x-www-form-urlencoded;charset=UTF-8';//tipo del documento
    
    //Revisamon si hay un ID de producto:
    if(document.getElementById("txtIdCategoria").value.trim().length === 0)
        categoria.id = 0;
    else
        categoria.id = parseInt(document.getElementById("txtIdCategoria").value.trim());
    
    categoria.descripcion = document.getElementById("txtNombre").value;
    
    params  = {
                categoria : JSON.stringify(categoria)
    };
    
    resp = await fetch(url,
                        {
                            method:"POST",
                            headers:{'Content-Type' : ctype},
                            body : new URLSearchParams(params)
                        });
    datos = await resp.json();
    
    if (datos.error != null)
    {
        Swal.fire("", "Error al guardar categoria", "warning");
        return;
    }
    
    if (datos.exception != null)
    {
        Swal.fire("", datos.exception, "danger");
        return;
    }
    
    document.getElementById("txtIdCategoria").value = datos.id;
    /*Swal.fire('Movimiento realizado.', 
              'Datos del categoria guardados', 
              'success');*/
    //consultarProductos();
}

export async function borrar(){
    let url='api/categoria/softdelete';
    let categoria = new Object();
    let params = null;//parametros del servicio
    let resp = null;//respuesta del servicio
    let datos = null;//datos JSON de respuesta
    let ctype = 'application/x-www-form-urlencoded;charset=UTF-8';//tipo del documento
    
    //Revisamon si hay un ID de producto:
    if(document.getElementById("txtIdCategoria").value.trim().length === 0)
        categoria.id = 0;
    else
        categoria.id = parseInt(document.getElementById("txtIdCategoria").value.trim());
    
    
    
    
    params  = {
                categoria : JSON.stringify(categoria)
    };
    
    resp = await fetch(url,
                        {
                            method:"POST",
                            headers:{'Content-Type' : ctype},
                            body : new URLSearchParams(params)
                        });
    datos = await resp.json();
    
    if (datos.error != null)
    {
        Swal.fire("", "Error al borrar la categoria", "warning");
        return;
    }
    
    if (datos.exception != null)
    {
        Swal.fire("", datos.exception, "danger");
        return;
    }
    
    document.getElementById("txtIdCategoria").value = datos.id;
    /*Swal.fire('Movimiento realizado.', 
              'Producto eliminado', 
              'success');
    consultarProductos();*/
}

