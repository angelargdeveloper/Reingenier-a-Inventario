let compra = [];
let proveedor = [];
let producto =[];
/*
let txtMonto = [];
let txtDescuento = [];
let txtKilos = [];
let txtPrecio = [];*/

export async function inicializarModulo() {
    console.log("entra a inicializarModulo");
    setDetalleCompraVisible(false);
    consultarCompra();
    consultarProveedor();
    consultarProductos();
}

async function consultarCompra() {
    let url = "api/compra/getAll";
    let resp = await fetch(url);
    let datos = await resp.json();
    
    console.log("consultarCompra", datos)
    
    if (datos.error != null) {
        Swal.fire("", "Error al consultar proveedor", "warning");
        return;
    }
    
    if (datos.exception != null) {
        Swal.fire("", datos.exception, "danger");
        return;
    }
    
    compra = datos;
    fillTableCompra();
}

function fillTableCompra() {
    let contenido = '';
    for (let i = 0; i < compra.length; i++) {
        
        console.log(compra[i]);
        
        //if(compra[i].estatus === 1){
            contenido += '<tr>' +
                '<td>' + compra[i].proveedor.nombre+ '</td>' +
                '<td>' + compra[i].producto.nombre + '</td>' +
                '<td>' + compra[i].producto.precio.toFixed(2) + '</td>' +
                '<td>' + compra[i].kilos + '</td>' +
                '<td>' + compra[i].descuento + '</td>' +
                '<td>' + compra[i].precioCompra.toFixed(2) + '</td>' +
                '<td>' + compra[i].fecha + '</td>' +
                '<td>' + '<a href="#" onclick="cm.mostrarDetalleCompra(' + i + ');"><i class="fas fa-pen text-info"></i></a>' + '</td>' +
                '</tr>';
        //}
    }
    document.getElementById("tbodyCompra").innerHTML = contenido;
}


export function setDetalleCompraVisible(valor) {
    if (valor) {
        document.getElementById("divDetalleCompra").style.display = '';
        document.getElementById("divCatalogoProductos").style.display = 'none';
    } else {
        document.getElementById("divDetalleCompra").style.display = 'none';
        document.getElementById("divCatalogoProductos").style.display = '';
    }
}

export async function mostrarDetalleCompra(pos) {
    let c = compra[pos];

    document.getElementById("txtIdCompra").value = c.id;
    document.getElementById("cmbProveedor").value = c.proveedor.id;
    document.getElementById("cmbProducto").value = c.producto.id;
    document.getElementById("txtPrecio").value = c.producto.precio.toFixed(2);
    document.getElementById("txtKilos").value = c.kilos;
    document.getElementById("txtDescuento").value = c.descuento;

    // Llama a la función calcularMonto para actualizar el monto total de la compra
    calcularMonto();
    //obtenerPrecioProducto();
    document.getElementById("txtFecha").value = c.fecha;

    setDetalleCompraVisible(true);
}


async function consultarProveedor() {
    let url = "api/proveedor/getAll";
    let resp = await fetch(url);
    let datos = await resp.json();

    if (datos.error != null) {
        Swal.fire("", "Error al consultar proveedor", "warning");
        return;
    }
    
    if (datos.exception != null) {
        Swal.fire("", datos.exception, "danger");
        return;
    }
    
    proveedor = datos;
    fillComboBoxProveedor();
}

function fillComboBoxProveedor() {
    let contenido = '';
    for(let i = 0; i < proveedor.length; i++) {
        if(proveedor[i].estatus === 1) {
            contenido += '<option value="' + proveedor[i].id + '" data-estatus="' + proveedor[i].estatus + '">' + 
                         proveedor[i].nombre +
                         '</option>';
        }
    }
    document.getElementById('cmbProveedor').innerHTML = contenido;
}

async function consultarProductos() {
    let url = "api/producto/getAll";
    let resp = await fetch(url);
    let datos = await resp.json();
    
    if (datos.error != null) {
        Swal.fire("", "Error al consultar productos", "warning");
        return;
    }
    
    if (datos.exception != null) {
        Swal.fire("", datos.exception, "danger");
        return;
    }
    
    producto = datos;
    fillComboBoxProductos();
}

function fillComboBoxProductos() {
    let contenido = '';
    for (let i = 0; i < producto.length; i++) {
        if (producto[i].estatus === 1) {
            contenido += '<option value="' + producto[i].id + '">' + 
                         producto[i].nombre + 
                         '</option>';
        }
    }
    document.getElementById('cmbProducto').innerHTML = contenido;
}

export async function save() {
    let url = 'api/compra/save';
    let compra = {};
    let detallesCompra = [];
    let params = null;
    let resp = null;
    let datos = null;
    let ctype = 'application/x-www-form-urlencoded;charset=UTF-8';

    if (document.getElementById("txtIdCompra").value.trim().length === 0)
        compra.id = 0;
    else
        compra.id = parseInt(document.getElementById("txtIdCompra").value.trim());

    compra.proveedor = { id: parseInt(document.getElementById("cmbProveedor").value) };
    compra.fecha = document.getElementById("txtFecha").value;

    let detalleCompra = {
        producto: {
            id: parseInt(document.getElementById("cmbProducto").value)
        },
        kilos: parseFloat(document.getElementById("txtKilos").value),
        precioUnitario: parseFloat(document.getElementById("txtPrecio").value),
        descuento: parseFloat(document.getElementById("txtDescuento").value),
        precioCompra: parseFloat(document.getElementById("txtMonto").value) // Agrega el precio de compra aquí
    };

    detallesCompra.push(detalleCompra);

    compra.detalleCompras = detallesCompra;  

    // Asignar precioCompra al campo txtMonto
    document.getElementById("txtMonto").value = detalleCompra.precioCompra.toFixed(2);
    console.log("Precio total de compra", detalleCompra.precioCompra);
    
    params = {
        compra: JSON.stringify(compra)
    };
    resp = await fetch(url, {
        method: "POST",
        headers: { 'Content-Type': ctype },
        body: new URLSearchParams(params)
    });
    datos = await resp.json();
    console.log("Datos respuesta ", datos);

    if (datos.error != null) {
        Swal.fire("", "Error al guardar la Compra", "warning");
        return;
    }

    if (datos.exception != null) {
        Swal.fire("", datos.exception, "error");
        return;
    }

    document.getElementById("txtIdCompra").value = datos.id;
    Swal.fire('Movimiento realizado.', 'Datos de Compra guardados', 'success');
    consultarCompra();
    calcularMonto();
    //console.log("Precio total de compra completo", detalleCompra.precioCompra);
}


export async function softDelete() {
    let url = 'api/compra/softdelete';
    let compra = {};
    let params = null;
    let resp = null;
    let datos = null;
    let ctype = 'application/x-www-form-urlencoded;charset=UTF-8';

    if(document.getElementById("txtIdCompra").value.trim().length === 0)
        compra.id = 0;
    else
        compra.id = parseInt(document.getElementById("txtIdCompra").value.trim());

    params = {
        compra: JSON.stringify(compra)
    };
    resp = await fetch(url, {
        method: "DELETE",
        headers: { 'Content-Type': ctype },
        body: new URLSearchParams(params)
    });
    datos = await resp.json();

    if (datos.error != null) {
        Swal.fire("", "Error al guardar la compra", "warning");
        return;
    }

    if (datos.exception != null) {
        Swal.fire("", datos.exception, "danger");
        return;
    }

    document.getElementById("txtIdCompra").value = datos.id;

    Swal.fire('Movimiento realizado.', 'Datos de compra eliminados ' + JSON.stringify(compra), 'success');
    consultarCompra();
}

export function limpiarFormulario() {
    document.getElementById("txtIdCompra").value = "";
    document.getElementById("cmbProveedor").value = "";
    document.getElementById("cmbProducto").value = "";
    document.getElementById("txtPrecio").value = "0";
    document.getElementById("txtKilos").value = "0";
    document.getElementById("txtDescuento").value = "0";
    document.getElementById("txtMonto").value = "";
    document.getElementById("txtFecha").value = "";
}

export async function obtenerPrecioProducto() {
    let cmbProducto = document.getElementById("cmbProducto");
    let txtPrecio = document.getElementById("txtPrecio");
    
    // Obtener el precio del producto seleccionado
    let precioProducto = producto.find(item => item.id === parseInt(cmbProducto.value)).precio;
    
    // Mostrar el precio en el campo correspondiente
    txtPrecio.value = precioProducto;
}

export function calcularMonto() {

   // Obtenemos los valores de los elementos del DOM
    let txtPrecio = parseFloat(document.getElementById("txtPrecio").value);
    let txtKilos = parseFloat(document.getElementById("txtKilos").value);
    let txtDescuento = parseFloat(document.getElementById("txtDescuento").value);
    let txtMonto = document.getElementById("txtMonto");
/*
    // Verificamos si los valores son numéricos
    if (isNaN(txtPrecio) || isNaN(txtKilos) || isNaN(txtDescuento)) {
        // Mostramos un mensaje de error si los valores no son numéricos
        txtMonto.value = "Error: Los valores ingresados no son válidos";
        return;
    }*/

    // Calculamos el monto
    let monto = (txtPrecio * txtKilos) - (txtPrecio * txtKilos * txtDescuento / 100);
    
    // Mostramos el monto calculado
    txtMonto.value = monto.toFixed(2);
}