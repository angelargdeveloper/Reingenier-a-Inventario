let productos = [];
let categorias = [];

export function inicializarModulo(){
    setDetalleProductoVisible(false);
    consultarCategorias();
    consultarProductos();
}

async function consultarProductos()
{
    let url = "api/producto/getAll";
    let resp = await fetch(url);
    let datos = await resp.json();
    
    if (datos.error != null)
    {
        Swal.fire("", "Error al consultar productos", "warning");
        return;
    }
    
    if (datos.exception != null)
    {
        Swal.fire("", datos.exception, "danger");
        return;
    }
    
    productos = datos;
    fillTableProductos();
}

function fillTableProductos()
{
    let contenido = '';
    for (let i = 0; i < productos.length; i++)
    {
        if(productos[i].estatus === 1){
            contenido +=    '<tr>' +
                                '<td>' + productos[i].id + '</td>' +
                                '<td>' + productos[i].nombre + '</td>' +
                                '<td>' + productos[i].categoria.descripcion + '</td>' +
                                '<td>' + productos[i].precio + '</td>' +
                                '<td>' + productos[i].cantidad + '</td>' +
                                '<td>' + productos[i].estatus + '</td>' +
                                '<td><a href="#" onclick="cm.mostrarDetalleProducto(' + i + ');"><i class="fa-solid fa-bars text-info"></i></a>' + '</td>' +
                            '</tr>';
        }
    }
    document.getElementById("tbodyProductos").innerHTML = contenido;
}

async function consultarCategorias(){
    let url = "api/categoria/getAll";
    let resp = await fetch(url);
    let datos = await resp.json();
    
    if (datos.error != null)
    {
        Swal.fire("", "Error al consultar categorias", "warning");
        return;
    }
    
    if (datos.exception != null)
    {
        Swal.fire("", datos.exception, "danger");
        return;
    }
    
    categorias = datos;
    fillComboBoxCategorias();
}

function fillComboBoxCategorias(){
    let contenido = '';
    
    for(let i = 0; i < categorias.length; i++){
        contenido+= '<option value="'+categorias[i].id+'">'+
                                      categorias[i].descripcion+
                     '</option>';
    }
    document.getElementById('cmbCategoria').innerHTML = contenido;
}

export async function save(){
    let url='api/producto/save';
    let producto = new Object();
    let params = null;//parametros del servicio
    let resp = null;//respuesta del servicio
    let datos = null;//datos JSON de respuesta
    let ctype = 'application/x-www-form-urlencoded;charset=UTF-8';//tipo del documento
    
    //Revisamon si hay un ID de producto:
    if(document.getElementById("txtIdProducto").value.trim().length === 0)
        producto.id = 0;
    else
        producto.id = parseInt(document.getElementById("txtIdProducto").value.trim());
    
    producto.nombre = document.getElementById("txtNombre").value;
    producto.precio = parseFloat(document.getElementById("txtPrecio").value);
    producto.cantidad = parseFloat(document.getElementById("txtCantidad").value);
    
    producto.categoria = new Object();
    producto.categoria.id = parseInt(document.getElementById("cmbCategoria").value);
    
    params  = {
                producto : JSON.stringify(producto)
    };
    
    resp = await fetch(url,
                        {
                            method:"POST",
                            headers:{'Content-Type' : ctype},
                            body : new URLSearchParams(params)
                        });
    datos = await resp.json();
    
    if (datos.error != null)
    {
        Swal.fire("", "Error al guardar producto", "warning");
        return;
    }
    
    if (datos.exception != null)
    {
        Swal.fire("", datos.exception, "danger");
        return;
    }
    
    document.getElementById("txtIdProducto").value = datos.id;
    /*Swal.fire('Movimiento realizado.', 
              'Datos del producto guardados', 
              'success');*/
    consultarProductos();
}

export function mostrarDetalleProducto(pos){
    
    let p = productos[pos];
    
    document.getElementById("txtIdProducto").value = p.id;
    document.getElementById("txtNombre").value = p.nombre;
    document.getElementById("txtPrecio").value = p.precio;
    document.getElementById("txtCantidad").value = p.cantidad;
    document.getElementById("cmbCategoria").value = p.categoria.id;
    setDetalleProductoVisible(true);
}

export function limpiarFormulario(){
    
    document.getElementById("txtIdProducto").value = "";
    document.getElementById("txtNombre").value = "";
    document.getElementById("txtPrecio").value = "";
    document.getElementById("txtCantidad").value = "";
    document.getElementById("cmbCategoria").value = "1";
}

export function setDetalleProductoVisible(valor){
    
    if(valor){
        document.getElementById("divDetalleProducto").style.display = '';
        document.getElementById("divCatalogoProductos").style.display = 'none';
    }
    else{
        document.getElementById("divDetalleProducto").style.display = 'none';
        document.getElementById("divCatalogoProductos").style.display = '';
    }
}


export async function borrar(){
    let url='api/producto/borrar';
    let producto = new Object();
    let params = null;//parametros del servicio
    let resp = null;//respuesta del servicio
    let datos = null;//datos JSON de respuesta
    let ctype = 'application/x-www-form-urlencoded;charset=UTF-8';//tipo del documento
    
    //Revisamon si hay un ID de producto:
    if(document.getElementById("txtIdProducto").value.trim().length === 0)
        producto.id = 0;
    else
        producto.id = parseInt(document.getElementById("txtIdProducto").value.trim());
    
    
    
    
    params  = {
                producto : JSON.stringify(producto)
    };
    
    resp = await fetch(url,
                        {
                            method:"POST",
                            headers:{'Content-Type' : ctype},
                            body : new URLSearchParams(params)
                        });
    datos = await resp.json();
    
    if (datos.error != null)
    {
        Swal.fire("", "Error al borrar el producto", "warning");
        return;
    }
    
    if (datos.exception != null)
    {
        Swal.fire("", datos.exception, "danger");
        return;
    }
    
    document.getElementById("txtIdProducto").value = datos.id;
   /* Swal.fire('Movimiento realizado.', 
              'Producto eliminado', 
              'success');*/
    consultarProductos();
}