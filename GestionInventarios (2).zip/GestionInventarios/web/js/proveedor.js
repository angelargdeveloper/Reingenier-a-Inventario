let proveedor= [];

export async function inicializarModulo()
{
    setDetalleProveedorVisible(false);
    consultarProveedor();
}

async function consultarProveedor()
{
    let url = "api/proveedor/getAll";
    let resp = await fetch(url);
    let datos = await resp.json();
    
    if (datos.error != null)
    {
        Swal.fire("", "Error al consultar proveedor", "warning");
        return;
    }
    
    if (datos.exception != null)
    {
        Swal.fire("", datos.exception, "danger");
        return;
    }
    
    proveedor = datos;
    fillTableProveedor();
}

function fillTableProveedor()
{
    let contenido = '';
    for (let i = 0; i < proveedor.length; i++)
    {
        if(proveedor[i].estatus === 1)
        {
        contenido +=    '<tr>' +
                            '<td>' + proveedor[i].id + '</td>' +
                            '<td>' + proveedor[i].nombre + '</td>' +
                            '<td>' + proveedor[i].razonSocial + '</td>' +
                            '<td>' + proveedor[i].rfc + '</td>' +
                            '<td>' + proveedor[i].email + '</td>' +
                            '<td>' + proveedor[i].tFijo + '</td>' +
                            '<td>' + proveedor[i].tMovil + '</td>' +
                            '<td>' + proveedor[i].estatus + '</td>' +
                            '<td>' +  '<a href="#" onclick="cm.mostrarDetalleProveedor('+i+');"<i class="fas fa-pen text-info"></i></a>'+'</td>'+
                        '</tr>';
        }
    }
    document.getElementById("tbodyProveedor").innerHTML = contenido;
}

export function setDetalleProveedorVisible(valor)
{
    if(valor)
    {
        document.getElementById("divDetalleProveedor").style.display='';
        document.getElementById("divCatalogoProveedor").style.display='none';
    }
    else
    {
        document.getElementById("divDetalleProveedor").style.display='none';
        document.getElementById("divCatalogoProveedor").style.display='';
    }
}

export function mostrarDetalleProveedor(pos)
{
    let p = proveedor[pos];
    setDetalleProveedorVisible(true);
    
    document.getElementById("txtIdProveedor").value = p.id;
    document.getElementById("txtNombre").value = p.nombre;
    document.getElementById("txtRazonSocial").value = p.razonSocial;
    document.getElementById("txtRFC").value = p.rfc;
    document.getElementById("txtEmail").value = p.email;
    document.getElementById("txtTelFijo").value = p.tFijo;
    document.getElementById("txtTelMovil").value = p.tMovil;

    
}


export async function save()
{
    let url = 'api/proveedor/save';
    let proveedor = new Object();
    let params = null; //Parametros del Servicio
    let resp = null; //Respuesta del Servicio
    let datos = null; //Datos JSON de respuesta
    let ctype = 'application/x-www-form-urlencoded;charset=UTF-8';
    
    //Revisamos si hay un ID de producto:
    if (document.getElementById("txtIdProveedor").value.trim().length === 0)
        proveedor.id = 0;
    else
        proveedor.id = parseInt(document.getElementById("txtIdProveedor").value.trim());
    
    proveedor.nombre = document.getElementById("txtNombre").value;
    proveedor.razonSocial = document.getElementById("txtRazonSocial").value;
    proveedor.rfc = document.getElementById("txtRFC").value.toUpperCase();
    proveedor.email = document.getElementById("txtEmail").value;
    proveedor.tFijo = document.getElementById("txtTelFijo").value;
    proveedor.tMovil = document.getElementById("txtTelMovil").value;

    
    params = {
                proveedor : JSON.stringify(proveedor)
             };
             
    resp = await fetch( url, 
                        {   method:"POST",
                            headers:{'Content-Type': ctype},
                            body: new URLSearchParams(params)
                        });
    datos = await resp.json();
    
    if (datos.error != null)
    {
        Swal.fire("", "Error al guardar Proveedor.", "warning");
        return;
    }
    
    if (datos.exception != null)
    {
        Swal.fire("", datos.exception, "danger");
        return;
    }
    
    //Si llegamos hasta aqui, significa que todo salio bien :)
    document.getElementById("txtIdProveedor").value = datos.id;
    Swal.fire('Movimiento realizado.', 
              'Datos de Proveedor guardados.', 
              'success');
    consultarProveedor();
}


export async function softDelete() // Declara una función asíncrona llamada 'softDelete' y la exporta como parte del módulo.
{
    let url = 'api/proveedor/softdelete'; // Declara una variable llamada 'url' y la inicializa con la URL de la API para guardar productos.
    let proveedor = new Object(); // Declara una variable llamada 'producto' y la inicializa como un objeto vacío.
    let params = null; // Declara una variable llamada 'params' y la inicializa como nula. Se utilizará para los parámetros del servicio.
    let resp = null; // Declara una variable llamada 'resp' y la inicializa como nula. Se utilizará para la respuesta del servicio.
    let datos = null; // Declara una variable llamada 'datos' y la inicializa como nula. Se utilizará para los datos JSON de respuesta.
    let ctype = 'application/x-www-form-urlencoded;charset=UTF-8'; // Declara una variable llamada 'ctype' y la inicializa con el tipo de documento.
    
    // Revisamos si hay un ID de producto:
    if(document.getElementById("txtIdProveedor").value.trim().length === 0) // Comprueba si el campo de ID del producto está vacío.
        proveedor.id = 0; // Establece el ID del producto como 0.
    else
        proveedor.id = parseInt(document.getElementById("txtIdProveedor").value.trim()); // Convierte y asigna el ID del producto como un entero.
    
        
    params = { // Asigna los parámetros para la solicitud al servicio.
                proveedor : JSON.stringify(proveedor) // Convierte el objeto 'producto' a una cadena JSON y lo asigna como un parámetro llamado 'producto'.
             };
    resp = await fetch(url, // Realiza una solicitud a la URL especificada.
                       { method:"POST", // Utiliza el método POST para la solicitud.
                         headers:{'Content-Type': ctype}, // Establece el tipo de contenido de la solicitud.
                         body: new URLSearchParams(params) // Codifica los parámetros como datos de formulario URL-encoded y los asigna al cuerpo de la solicitud.
                       });
    datos = await resp.json(); // Lee el cuerpo de la respuesta como JSON.
    
    if (datos.error != null) // Comprueba si hay un error en los datos obtenidos.
    {
        Swal.fire("", "Error al borrar el proveedor", "warning"); // Muestra un mensaje de alerta al usuario.
        return; // Retorna y sale de la función.
    }
    
    if (datos.exception != null) // Comprueba si hay una excepción en los datos obtenidos.
    {
        Swal.fire("", datos.exception, "danger"); // Muestra un mensaje de alerta al usuario con la excepción obtenida.
        return; // Retorna y sale de la función.
    }
    
    // Si llegamos hasta aquí, significa que todo salió bien.
    document.getElementById("txtIdProveedor").value = datos.id; // Asigna el ID del producto obtenido a un campo de entrada en el formulario.
    
    Swal.fire('Movimiento realizado.', // Muestra una notificación con un mensaje de éxito.
              'Datos de proveedor eliminados ', 
              'success');
    consultarProveedor(); 
}

export function limpiarFormulario()
{
    document.getElementById("txtIdProveedor").value = "";
    document.getElementById("txtNombre").value = "";
    document.getElementById("txtRazonSocial").value = "";
    document.getElementById("txtRFC").value = "";
    document.getElementById("txtEmail").value ="";
    document.getElementById("txtTelFijo").value = "";
    document.getElementById("txtTelMovil").value = "";
}
