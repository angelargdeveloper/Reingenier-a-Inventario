let cm = null;//variable que contiene el modulo actual (Current Module)

async function cargarModuloProductos(){
    let resp = await fetch('modules/producto.html');
    let contenido = await resp.text();
    document.getElementById('contenedorPrincipal').innerHTML = contenido;
    import('./producto.js')
    .then(obj => {
        cm = obj;
        cm.inicializarModulo();
    });
}
async function cargarModuloUsuario(){
    let resp = await fetch('modules/usuario.html');
    let contenido = await resp.text();
    document.getElementById('contenedorPrincipal').innerHTML = contenido;
    import('./usuario.js')
    .then(obj => {
        cm = obj;
        cm.inicializarModulo();
    });
}
async function cargarModuloAreas(){
    let resp = await fetch('modules/area.html');
    let contenido = await resp.text();
    document.getElementById('contenedorPrincipal').innerHTML = contenido;
    import('./area.js')
    .then(obj => {
        cm = obj;
        cm.inicializarModulo();
    });
}
async function cargarModuloCategorias(){
    let resp = await fetch('modules/categoria.html');
    let contenido = await resp.text();
    document.getElementById('contenedorPrincipal').innerHTML = contenido;
    import('./categoria.js')
    .then(obj => {
        cm = obj;
        cm.inicializarModulo();
    });
}
async function cargarModuloEmpleado(){
    let resp = await fetch('modules/empleado.html');
    let contenido = await resp.text();
    document.getElementById('contenedorPrincipal').innerHTML = contenido;
    import('./empleado.js')
    .then(obj => {
        cm = obj;
        cm.inicializarModulo();
    });
}
async function cargarModuloProveedor(){
    let resp = await fetch('modules/proveedor.html');
    let contenido = await resp.text();
    document.getElementById('contenedorPrincipal').innerHTML = contenido;
    import('./proveedor.js')
    .then(obj => {
        cm = obj;
        cm.inicializarModulo();
    });
}
async function cargarModuloCompra(){
    let resp = await fetch('modules/compra.html');
    let contenido = await resp.text();
    document.getElementById('contenedorPrincipal').innerHTML = contenido;
    import('./compra.js')
    .then(obj => {
        cm = obj;
        cm.inicializarModulo();
    });
}
