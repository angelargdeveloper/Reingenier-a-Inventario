create database gestion_inv;

use gestion_inv;

CREATE TABLE area
(
    idArea     		 INTEGER PRIMARY KEY AUTO_INCREMENT,
    descripcion      VARCHAR(50),
    estatus			 INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE empleado
(
    idEmpleado      INTEGER PRIMARY KEY AUTO_INCREMENT,
    nombre          VARCHAR(50),
    fechaAlta       DATE,
    fechaNac        DATE,
    direccion       VARCHAR(50),
    poblacion       VARCHAR(50),
    codPostal       VARCHAR(5),
    telefono        VARCHAR(20),
    idArea   		INTEGER,
    estatus	 		INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT fk_empleado_area 
    FOREIGN KEY (idArea) REFERENCES area(idArea)
);

CREATE TABLE usuario
(
    idUsuario     	 INTEGER PRIMARY KEY AUTO_INCREMENT,
    usuario      	 VARCHAR(20),
    pass			 varchar(15),
    idEmpleado		 INTEGER,
    estatus	 		INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT fk_usuario_empleado 
    FOREIGN KEY (idEmpleado) REFERENCES empleado(idEmpleado)
);

CREATE TABLE proveedor
(
    idProveedor     INTEGER NOT NULL PRIMARY KEY AUTO_INCREMENT,
    nombre          VARCHAR(129) NOT NULL,
    razonSocial     VARCHAR(129) NOT NULL,
    rfc             VARCHAR(15) NOT NULL DEFAULT '',
    email           VARCHAR(129) NOT NULL  DEFAULT '',
    telefonoFijo    VARCHAR(10) NOT NULL DEFAULT '',
    telefonoMovil   VARCHAR(10) NOT NULL DEFAULT '',
    estatus	 		INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE categoria
(
    idCategoria     INTEGER PRIMARY KEY AUTO_INCREMENT,
    descripcion      VARCHAR(50),
    estatus	 	INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE producto
(
    idProducto  INTEGER PRIMARY KEY AUTO_INCREMENT,
    nombre      VARCHAR(50),
    idCategoria INTEGER,
    precio      FLOAT,
    cantidad 	INTEGER,
    estatus	 	INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT fk_producto_categoria
    FOREIGN KEY (idCategoria) REFERENCES categoria(idCategoria)
);

CREATE TABLE venta
(
    idVenta     INTEGER PRIMARY KEY NOT NULL AUTO_INCREMENT,
    idEmpleado  INTEGER REFERENCES empleado(idEmpleado),
    fechaVenta  DATETIME,    
    estatus	 	INTEGER NOT NULL DEFAULT 1,
    CONSTRAINT  fk_venta_empleado
    FOREIGN KEY (idEmpleado) REFERENCES empleado(idEmpleado)
);

CREATE TABLE detalle_venta
(
    idVenta         INTEGER NOT NULL,
    idProducto      INTEGER NOT NULL,
    cantidad        INTEGER NOT NULL DEFAULT 0,
    precioVenta     FLOAT NOT NULL DEFAULT 0,
    descuento       FLOAT NOT NULL DEFAULT 0,
    CONSTRAINT      fk_dv_venta
    FOREIGN KEY     (idVenta) REFERENCES venta(idVenta),
    CONSTRAINT      fk_dv_producto
    FOREIGN KEY     (idProducto) REFERENCES producto(idProducto)
);