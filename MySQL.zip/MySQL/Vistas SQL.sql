USE gestion_inv;

DROP VIEW IF EXISTS v_empleado;
CREATE VIEW v_empleado AS
    SELECT  E.idEmpleado,
            E.nombre,
            E.fechaAlta,
			E.fechaNac, 
            E.direccion,
            E.poblacion,
            E.codPostal,
            E.telefono,
            A.idArea AS Id,
            A.descripcion AS Area,
            A.estatus AS AEst,
            E.estatus 
    FROM	gestion_inv.empleado E 
            INNER JOIN gestion_inv.area A ON E.idArea = A.idArea;
            
DROP VIEW IF EXISTS v_producto;
CREATE VIEW v_producto AS
    SELECT  P.idProducto,
            P.nombre,
            P.precio,
            P.cantidad,
            P.estatus,
            C.idCategoria AS Id,
            C.descripcion AS Categoria,
            C.estatus as Est
    FROM	producto P 
            INNER JOIN categoria C ON p.idCategoria = C.idCategoria;

DROP VIEW IF EXISTS v_venta;
CREATE VIEW v_venta AS
SELECT  
		v.idVenta,
        E.idEmpleado,
        E.nombre AS nombreEmpleado,
        E.estatus,
        P.nombre AS nombreProducto,
        P.idProducto,
        P.precio AS precioUnitario,
        P.cantidad AS PCant,
        P.estatus AS PEst,
        Dv.cantidad,
        Dv.precioVenta,
        Dv.descuento,
        V.fechaVenta,
        V.estatus AS VEst
FROM    venta V 
        INNER JOIN detalle_venta Dv ON V.idVenta = Dv.idVenta
        INNER JOIN producto P ON Dv.idProducto = P.idProducto
        INNER JOIN empleado E ON V.idEmpleado = E.idEmpleado;

DROP VIEW IF EXISTS v_usuario;
CREATE VIEW v_usuario AS 
SELECT 
		U.idUsuario idUsuario,
        U.usuario Usuario,
        U.pass Pass,
        E.idEmpleado idEmpleado,
        E.nombre ENombre,
        E.fechaAlta EAlta,
        E.fechaNac ENac,
        E.direccion EDir,
        E.poblacion EPob,
        E.codPostal ECod,
        E.telefono ETel,
        E.estatus EEst,
        A.idArea idArea,
        A.descripcion ADes,
        A.estatus AEst,
        U.estatus UEst
        FROM usuario U
        INNER JOIN empleado E ON U.idEmpleado = E.idEmpleado
        INNER JOIN area A ON E.idArea = A.idArea;
        
select * from v_venta;
SELECT * FROM empleado;
SELECT * FROM producto;
INSERT INTO gestion_inv.area(descripcion)value("gerencia");
INSERT INTO gestion_inv.empleado(nombre,fechaAlta,fechaNac,direccion,poblacion,codPostal,telefono,idArea)
VALUES("jordi","2024-08-04","2003-06-07","alcatraces","leon","37118","4774907752",2);

INSERT INTO categoria(descripcion)VALUE("Limpieza");
INSERT INTO producto(nombre,idCategoria,precio,cantidad)VALUES("papel",1,19.50,20);

INSERT INTO venta(idEmpleado,fechaVenta)VALUES(1,"2024-08-04");
INSERT INTO detalle_venta(idVenta,idProducto,cantidad,precioVenta)VALUES(1,1,10,15.6);

INSERT INTO usuario(usuario,pass,idEmpleado)VALUES("AlexMoya7","Soydeleon",1);
select * from v_usuario;